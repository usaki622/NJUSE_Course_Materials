lab7-软件体系结构设计文档

## 文档修改历史

| 修改人员 | 日期      | 修改原因                                                     | 版本号 |
| -------- | --------- | ------------------------------------------------------------ | ------ |
| 姚天翔   | 2022.6.29 | 完成软件体系结构设计文档整体框架，并完成财务模块和人力资源模块部分初步设计 | V1.0   |
| 练健恒   | 2022.6.30 | 添加销售模块部分                                             | V1.1   |
| 罗瑞航   | 2022.6.30 | 添加促销模块部分                                             | v1.2   |
| 姚天翔   | 2022.7.9  | 进行了细节的修改，对文档进行了完善                           | V1.3   |
|          |           |                                                              |        |

## 1 引言

## 1 引言

### 1.1 编制目的

本报告详细完成对ERP系统部分模块的概要设计，以达到指导详细设计和开发的目的，同时实现和测试人员以及用户的沟通。

本报告面向开发人员、测试人员及最终用户而编写，是了解系统的导航。

### 1.2 词汇表

| 词汇名称 | 词汇含义 | 备注   |
| ---- | ---- | ---- |
|      |      |      |

### 1.3 参考资料

(1)IEEE标准

(2)《软件工程与计算（卷二） 软件开发的技术基础》丁二玉、刘钦著

(3)ERP系统用例文档

(4)ERP系统需求规格说明文档

## 2 产品概述

此部分请参考ERP系统用例文档和软件需求规格说明中对产品的概括描述。



## 3 逻辑视图

- 处理静态设计模型

在本ERP系统中，选择了分层体系结构风格，将系统分为四部分（presentation, controller, service, data），从而达到很好地示意整个高层抽象的效果。其中Presentation部分包含了GUI页面的实现，Controller部分负责接受前端发送的请求并分发给相应的Service，Service部分负责业务逻辑的实现，data部分负责数据的持久化和访问。分层体系结构的逻辑视角和逻辑设计方案如下图所示。

<center><img src="lab7-软件体系结构设计文档.assets/image-20220630161811690.png" alt="image-20220630161811690" style="zoom: 67%;" />
    <div>图1 参照体系结构的包图表达逻辑视角</div>
</center>
<center><img src="lab7-软件体系结构设计文档.assets/image-20220710100857521.png" alt="image-20220710100857521.png" style="zoom: 67%;" />
    <div>图2 软件体系结构逻辑设计方案</div>
</center>

## 4 组合包图

### 4.1 开发包图

- 表示软件组件在开发时环境中的静态组织
  - 描述开发包以及相互间的依赖
  - 绘制开发包图

| 开发（物理）包                      | 依赖的其它开发包                                                                                                                                                 |
|------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| FinancialUI                  | BankController,PaymentController,PayrollController,ReceiptController,Vue组件包,JSONObject,RESTAPI                                                           |
| HrUI                         | HrController,PaywageControlller,Vue组件包,JSONObject,RESTAPI                                                                                                |
| SaleStrategyUI               | SaleStrategyController,CommodityController                                                                                                               |
| GiftUI                       | GiftSheetController                                                                                                                                      |
| InitUI                       | InitController                                                                                                                                           |
| BankController               | BankService                                                                                                                                              |
| PaymentController            | PaymentService                                                                                                                                           |
| PayrollController            | PayrollService                                                                                                                                           |
| ReceiptController            | ReceiptService                                                                                                                                           |
| PaywageControlller           | PaywageService                                                                                                                                           |
| HrController                 | SignInService,StaffService                                                                                                                               |
| SaleController               | SaleService, SaleReturnService                                                                                                                           |
| SaleStrategyController         | SaleStrategyService                                                                                                          |
| GiftSheetController            | GiftSheetService                                                                                                             |
| InitController                 | InitialInfoService |
| BankService                  | BankDao                                                                                                                                                  |
| PaymentService               | PaymentSheetMapper,PaymentSheetCheckListMapper,BankDao,CustomerDao                                                                                       |
| PayrollService               | PayrollSheetMapper,BankDao                                                                                                                               |
| ReceiptService               | ReceiptSheetMapper,ReceiptSheetTransferListMapper,CustomerDao,BankDao                                                                                    |
| SignInService                | SignInRecordMapper                                                                                                                                       |
| StaffService                 | StaffMapper,UserDao                                                                                                                                      |
| PaywageService               | Strategy                                                                                                                                                 |
| SaleService                  | SaleSheetDao,SaleReturnsSheetDao,ProductDao, CustomerDao,ProductService, CustomerService,WarehouseService,SaleCheckDao, FinancialService,PurchaseService |
| SaleReturnService            | SaleReturnsSheetDao, ProductDao, SaleSheetDao, CustomerService,WarehouseService,WarehouseDao, WarehouseOutputSheetDao                                    |
| SaleStrategyService            | SaleStrategyDao,GroupConditionContentDao                                                                                     |
| InitStrategyService            | InitMapper,CategoryDao,InitCategoryMapper,ProductDao,InitProductMapper,BankDao,InitBankMapper,CustomerDao,InitCustomerMapper |
| GiftSheetService               | GiftSheetDao,WarehouseDao,SaleSheetDao,GroupService                                                                          |
|                              |                                                                                                                                                          |
| BankDao                        | Entity,BaseMapper                                                                                                            |
| ReceiptSheetMapper             | Entity,BaseMapper                                                                                                            |
| ReceiptSheetTransferListMapper | Entity,BaseMapper                                                                                                            |
| PaymentSheetMapper             | Entity,BaseMapper                                                                                                            |
| PaymentSheetCheckListMapper    | Entity,BaseMapper                                                                                                            |
| PayrollSheetMapper             | Entity,BaseMapper                                                                                                            |
| SaleSheetDao                 | Entity                                                                                                                       |
| SaleReturnsSheetDao          | Entity                                                                                                                       |
| SaleStrategyDao                | po,BaseMapper                                                                                                                |
| GroupConditionContentDao       | Entity,BaseMapper                                                                                                            |
| GiftSheetDao                   | po,BaseMapper                                                                                                                |
| InitMapper                     | Entity,BaseMapper                                                                                                            |
| InitCategoryMapper             | Entity,BaseMapper                                                                                                            |
| InitProductMapper              | Entity,BaseMapper                                                                                                            |
| InitBankMapper                 | Entity,BaseMapper                                                                                                            |
| InitCustomerMapper             | Entity,BaseMapper                                                                                                            |
| SignInRecordMapper             | Entity,BaseMapper                                                                                                            |
| StaffMapper                    | Entity,BaseMapper                                                                                                            |
| UserDao                        | po                                                                                                                           |
| CategoryDao                    | po                                                                                                                           |
| ProductDao                     | po                                                                                                                           |
| BankDao                        | po                                                                                                                           |
| CustomerDao                    | po                                                                                                                           |
| vo                             |                                                                                                                              |
| po                             |                                                                                                                              |
| Strategy                       | Staff                                                                                                                        |
| Entity                         |                                                                                                                              |
| Vue组件库                         |                                                                                                                              |
| BaseMapper                     |                                                                                                                              |
| JSONObject                     |                                                                                                                              |
| RESTAPI                        |                                                                                                                              |

ERP平台客户端开发包图如图3所示，服务器端开发包图如图4所示

![image-20220710101036316](lab7-软件体系结构设计文档.assets/image-20220710101036316.png)

![image-20220710101059956](lab7-软件体系结构设计文档.assets/image-20220710101059956.png)

### 4.2 运行时进程

- 示意图：

<center><img src="lab7-软件体系结构设计文档.assets/image-20220630195439278.png" alt="image-20220630195439278.png" style="zoom: 67%;" />
    <div>图4 运行进程示意图</div>
</center>


### 4.3 物理部署

- 处理如何将软件组件映射到硬件设施
- 部署图

<center><img src="lab7-软件体系结构设计文档.assets/image-20220630200636587.png" alt="image-20220630200636587" style="zoom: 67%;" />
    <div>图5 部署图</div>
</center>


## 5 架构设计

- 描述功能分解和如何在不同的层中安排软件模块
  - 描述架构中的对象，包含架构图
  - 描述组件接口信息
    - 包含：语法、前置条件、后置条件

### 5.1 模块职责

客户端模块和服务端模块视图分别如图6和图7所示。客户端各层和服务端各层职责分别如表1和表2所示。

<center><img src="lab7-软件体系结构设计文档.assets/image-20220630202818134.png" alt="image-20220630202818134.png" style="zoom: 67%;" />
    <div>图6 客户端模块视图</div>
</center>

<center><img src="lab7-软件体系结构设计文档.assets/image-20220630203052754.png" alt="image-20220630203052754.png" style="zoom: 67%;" />
    <div>图7 服务器端模块视图</div>
</center>


- 表1 客户端各层职责

| 层       | 职责                           |
| ------- | ---------------------------- |
| 启动模块    | 负责初始化网络通信机制，启动用户界面           |
| 展示层     | 负责ERP用户界面，使用Vue.js框架实现       |
| 客户端网络模块 | 使用RESTful风格接口通过HTTP请求实现前后端通信 |

- 表2 服务器端各层职责

| 层        | 职责                     |
| -------- | ---------------------- |
| 启动模块     | 负责初始化网络通信机制，启动后端服务器    |
| 业务逻辑层    | 对于用户界面的输入进行业务处理逻辑      |
| 数据层      | 负责数据的持久化即数据访问接口        |
| 服务器端网络模块 | 通过RESTful风格接口处理前端发出的请求 |

- 层之间调用接口

| RESTAPI                                  | 客户端展示层   | 服务端控制层层  |
| ---------------------------------------- | -------- | -------- |
| SaleStrategyService<br/>GiftSheetService<br/>InitService<br/>SaleStrategyService<br/>GiftSheetService<br/>InitService<br/>BankService<br />PaymentService<br />PayrollService<br />ReceiptService<br />PaywageService<br />SignInService<br />StaffService<br />Strategy<br >SaleService<br>SaleReturnService | 服务端控制层   | 服务端业务逻辑层 |
| SaleStrategyDao<br/> GiftSheetDaoBankDao<br />GroupConditionDao<br/>InitCategoryMapper<br/>InitProductMapper<br/>InitCustomerMapper<br/> InitBankMapper<br/>InitMapper<br/>BankDao<br />ReceiptSheetMapper<br />ReceiptSheetTransferListMapper<br />PaymentSheetMapper<br />PaymentSheetCheckListMapper<br />PayrollSheetMapper<br />SignInRecordMapper<br />StaffMapper<br />UserMapper<br>SaleSheetDao<br>SaleReturnsSheetDao | 服务端业务逻辑层 | 服务端数据层   |

### 5.2 用户界面层分解

#### 5.2.1 职责 

- 类图


服务器端和客户端的用户界面设计接口是一致的，只是具体的页面不一样。用户界面类如图所示。

<center><img src="lab7-软件体系结构设计文档.assets/image-20220630204912755.png" alt="image-20220630204912755.png" style="zoom: 67%;" />
    <div>图1 参照体系结构的包图表达逻辑视角</div>
</center>


| 模块                 | 职责           |
| ------------------ | ------------ |
| BankController     | 负责财户界面相关     |
| PaymentController  | 负责付款单界面相关    |
| PayrollController  | 负责工资单界面相关    |
| ReceiptController  | 负责收款单界面相关    |
| PaywageControlller | 负责薪酬规则策略界面相关 |
| HrController       | 负责人力资源人员界面相关 |
| SaleController     | 负责销售人员界面相关   |
| SaleStrategyController | 负责促销策略界面相关   |
| GiftSheetController    | 负责赠品单界面相关    |
| InitController         | 负责期初建账界面相关   |
|                    |              |
|                    |              |
|                    |              |
|                    |              |

#### 5.2.2 接口规范

##### **Financial模块的接口规范**

| 接口名称                                     | 语法                                     | 前置条件 | 后置条件                                |
| ---------------------------------------- | -------------------------------------- | ---- | ----------------------------------- |
| BankController.createOrUpdateBank        | createOrUpdateBank(JSONObject obj)     | 输入合法 | 将账户信息传递给后端BankService               |
| BankController.deleteBank                | deleteBank(JSONObject obj)             | 输入合法 | 将被删除的账户信息传递给后端BankService           |
| BankController.getAllBank                | getAllBank()                           | 无    | 从BankService获得全部的账户信息               |
| ReceiptController.addReceiptSheet        | addReceiptSheet(JSONObject obj)        | 输入合法 | 将收款单信息传递给后端ReceiptService           |
| ReceiptController.addReceiptSheetContent | addReceiptSheetContent(JSONObject obj) | 输入合法 | 将收款单转账列表信息传递给后端ReceiptService       |
| ReceiptController.getAllReceiptSheet     | getAllReceiptSheet()                   | 无    | 从ReceiptService获得全部的收款单信息           |
| PaymentController.addPaymentSheet        | addPaymentSheet(JSONObject obj)        | 输入合法 | 将付款单信息传递给后端PaymentService           |
| PaymentController.addPaymentSheetContent | addPaymentSheetContent(JSONObject obj) | 输入合法 | 将付款单条目信息传递给后端PaymentService         |
| PaymentController.getAllPaymentSheet     | getAllPaymentSheet()                   | 无    | 从PaymentService获得全部的付款单信息           |
| PayrollController.getAllPayrollSheet     | getAllPayrollSheet()                   | 无    | 从PayrollService获得全部的工资单信息           |
| PayrollController.addPayrollSheet        | addPayrollSheet(JSONObject obj)        | 输入合法 | 将工资单信息传递给后端PayrollService           |
| PayWageController.PayWage                | PayWage(Staff staff)                   | 输入合法 | 将staff相关信息传递给payWageService，调用对应的策略 |
|                                          |                                        |      |                                     |

##### **Financial模块的服务接口**

| 服务名                                      | 服务                                       |
| ---------------------------------------- | ---------------------------------------- |
| BankService.createBank(Bank bank,Long id) | 将账户信息传给BankMapper                        |
| BankService.getAllBank()                 | 从BankMapper获得所有的账户                       |
| BankService.delBank(Long id)             | 将要删除的账户信息传给BankMapper                    |
| ReceiptService.addReceiptSheet(ReceiptSheet rs) | 将收款单信息传递给ReceiptSheetMapper              |
| ReceiptService.addReceiptSheetContent(ReceiptSheetContent rsc) | 将收款单转账列表信息传递给ReceiptSheetTransferListMapper |
| ReceiptService.getReceiptSheetList()     | 从ReceiptSheetMapper获得全部的收款单信息            |
| ReceiptService.getReceiptSheetContent(String rsId) | 从ReceiptSheetTransferListMapper获得收款单转账列表信息 |
| PaymentService.addPaymentSheet(PaymentSheet pms) | 将付款单信息传递给PaymentSheetMapper              |
| PaymentService.addPaymentSheetContent(PaymentSheetContent pmsc) | 将付款单条目信息传递给PaymentSheetCheckListMapper   |
| PaymentService.getPaymentSheetList()     | 从PaymentSheetMapper获得全部的付款单信息            |
| PaymentService.getPaymentSheetContent(String pmsId) | 从PaymentSheetCheckListMapper获得付款单条目信息    |
| PayrollService.addPayrollSheet(PayrollSheet prs) | 将工资单信息传递给PayrollSheetMapper              |
| PayrollService.getPayrollSheetList()     | 从PayrollSheetMapper获得全部的工资单信息            |
| PayWageService.paySalary(PayWagesStrategy strategy, Staff staff) | 从PayWagesStrategy调用对应的策略方法               |
|                                          |                                          |
|                                          |                                          |

##### **Hr模块的接口规范**

| 接口名称                     | 语法                           | 前置条件 | 后置条件                       |
| ------------------------ | ---------------------------- | ---- | -------------------------- |
| HrController.signIn      | signIn(JSONObject obj)       | 输入合法 | 将打卡信息传递给后端SignInService    |
| HrController.createStaff | createStaff(JSONObject obj)  | 输入合法 | 将员工信息传递给后端StaffService     |
| HrController.getAllStaff | getAllStaff()                | 无    | 从StaffService获得全部的员工信息     |
| HrController.deleteStaff | deleteStaff(JSONObject data) | 输入合法 | 将被删除的员工信息传递给后端StaffService |

##### **Hr模块的服务接口**

| 服务名                                  | 服务                                |
| ------------------------------------ | --------------------------------- |
| SignInService.addSign(SignIn signIn) | 将员工打卡信息传给SignInRecordMapper       |
| SignInService.getSign(String name)   | 从signInRecordMapper获取员工打卡信息       |
| UserService.getAllUser(User user)    | 从UserDao获取全部的用户信息                 |
| StaffService.addStaff(Staff staff)   | 将员工信息传给StaffMapper和UserMapper     |
| StaffService.getAllStaff()           | 从StaffMapper获取全部的员工信息             |
| StaffService.deleteStaff(Long id)    | 将要删除的员工信息传给StaffMapper和UserMapper |

##### **Sale模块的接口规范**

| 接口名称                             | 语法                                       | 前置条件 | 后置条件                                     |
| -------------------------------- | ---------------------------------------- | ---- | ---------------------------------------- |
| SaleController.checkSaleDetail   | checkSaleDetail(SaleDetailMessage sdm)   | 输入合法 | 将销售信息查询条件传递给后端PaymentService             |
| SaleController.getManageExprList | getManageExprList（ManageExprVO manageExprVO） | 输入合法 | 将销售历程查询信息传递给后端PaymentService             |
| SaleController.getContentById    | getContentById(String id)                | 输入合法 | 从SaleShhetService、SaleReturnsSheetService销售单中得到销售单的内容 |
| SaleController.hongChong         | hongchong(id)                            | 输入合法 | 向saleService传送红冲的单据id                    |
| SaleController.manageState       | manageState(String beginTime, String endTime) | 输入合法 | 将经营状况查询时间传给saleService                   |
|                                  |                                          |      |                                          |
|                                  |                                          |      |                                          |

##### Sale模块的服务接口

| 服务名                                      | 服务                                       |
| ---------------------------------------- | ---------------------------------------- |
| SaleService.checkSaleDetail(SaleDetailMessage sdm) | 将销售细节查询信息传递给SaleDao                      |
| SaleService.getManageExpr(ManageExprVo mev) | 将经营历程信息传递给SaleSheetDao和SaleReturnsSheetDao |
| SaleService.getSaleSheetContentById(String id) | 将销售单据的id传递给saleSheetDao                  |
| SaleReturnsService.getSaleReturnsContentById(String id) | 将销售退货单据的id传递给saleSheetDao                |
| SaleService.hongchong(String id)         | 将红冲单据id传递给saleSheeDao                    |
| SaleReturnsService.hongchong(String id)  | 将红冲单据id传递给saleReturnsSheeDao             |
| saleService.integrateToManageStateVO(Date beginTime, Date endTime) | 将开始日期和结束日期传递给saleSheetDao                |


##### **SaleStrategy模块的接口规范**

| 接口名称                                      | 语法                                 | 前置条件 | 后置条件                                              |
|-------------------------------------------|------------------------------------|------|---------------------------------------------------|
| SaleStrategyController.createSaleStrategy | createSaleStrategy(JSONObject obj) | 输入合法 | 将促销策略信息传递给后端SaleServiceImpls                      |
| SaleStrategyController.getAllSaleStrategy | getAllSaleStrategy()               | 无    | 从SaleService获得全部的促销信息                             |
| SaleStrategyController.getAllGroup        | getAllGroup(String saleStrategyId) | 输入合法 | 将saleStrategyId信息传递给SaleService                   |
| SaleStrategyController.deleteSaleStrategy | deleteStaff(String salStrategyId)  | 输入合法 | 将要被删除的策略的SaleStrategyId信息传递给后端SaleStrategyService |
| GiftSheetController.createGiftSheet | createGiftSheet(JSONObject obj)                   | 输入合法 | 将赠品单信息传递给GiftSheetService                   |
| GiftSheetController.getAllGiftSheet | getAllGiftSheet()                                 | 无    | 从GiftSheetService获取全部的赠品单信息                 |
| GiftSheetController.approval        | approval(String giftSheetId,GiftSheetState state) | 输入合法 | 将giftSheetId 和要改变的state信息传入GiftSheetService |



##### **SaleStrategy模块的服务接口**

| 服务名                                                                           | 服务                                                                    |
|-------------------------------------------------------------------------------|-----------------------------------------------------------------------|
| SimpleSaleStrategyImpl.createSaleStrategy(SaleStrategyVO saleStrategyVO)      | 将要添加的简单促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息    |
| GroupSaleStrategyImpl.createSaleStrategy(SaleStrategyVO saleStrategyVO)       | 将要添加的特价包促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息   |
| FillDeclineSaleStrategyImpl.createSaleStrategy(SaleStrategyVO saleStrategyVO) | 将要添加的满减、满送促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息 |
| SaleStrategyService.getAllSaleStrategy()                                      | 从SaleStrategyDao获取全部的促销策略信息                                           |
| SaleStrategyService.getAllGroup(String saleStrategyId)                        | 将需要查询赠品/特价包清单的促销策略id传递给GroupConditionContentDao                       |
| SaleStrategyService.deleteSaleStaff(String saleStrategyId)                    | 将要删除的促销策略信息传给SaleStrategyDao和GroupConditionContentDao。                |
| GiftSheetService.createGiftSheet( String saleSheetId,String saleStrategyId)   | 将要添加的赠品单信息传递给GiftSheetDao,SaleSheetId,GroupService，向表中插入相应信息          |
| GiftSheetService.getAllGiftSheet()                                            | 从GiftSheetDao获取全部赠品单信息                                                |
| GiftSheetService.approval(String giftSheetId,GiftSheetState state)            | 将赠品单信息和审批状态处理后传入GiftSheetDao,WarehouseDao中，更改相应状态                     |
| GroupService.getAllGroup(String saleStrategyId)                               | 将saleStrategyId传入GroupConditionContentDao中，获取相应的赠品/特价包清单              |

##### **Init模块的服务接口**
| 接口名称                       | 语法                         | 前置条件 | 后置条件                                        |
|----------------------------|----------------------------|------|---------------------------------------------|
| InitController.init        | init()                     | 无    | 使InitialInfoService执行期初建账函数init()。                 |
| InitController.getCategory | getCategory(String initId) | 输入合法 | 将建账套数initId信息传入InitialInfoService                  |
| InitController.getProduct  | getProduct(String initId)  | 输入合法 | 将建账套数initId信息传入InitialInfoService                  |
| InitController.getBank     | getBank(String initId)     | 输入合法 | 将建账套数initId信息传入InitialInfoService                  |
| InitController.getCustomer | getCustomer(String initId) | 输入合法 | 将建账套数initId信息传入InitialInfoService                  |


##### **Init模块的服务服务接口**

| 服务名                                                  | 服务                                                                                                                                    |
|------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| InitialInfoService.init()                            | 从CategoryDao,BankDao,ProductDao,CustomerDao中取出当前数据,向InitMapper,CategoryMapper,BankMapper,ProductMapper,CustomerMapper中插入当前数据，进行期初建账活动 |
| InitialInfoService.getAllInitCategory(String initId) | 向InitCategoryMapper中传入initId数据，得到这套账的所有商品类别信息。                                                                                        |
| InitialInfoService.getAllInitProduct(String initId)  | 向InitProductMapper中传入initId数据，得到这套账的所有商品类别信息。                                                                                         |
| InitialInfoService.getAllInitBank(String initId)     | 向InitBankMapper中传入initId数据，得到这套账的所有商品类别信息。                                                                                            |
| InitialInfoService.getAllInitCustomer(String initId) | 向InitCustomerMapper中传入initId数据，得到这套账的所有商品类别信息。                                                                                        |


#### 5.2.3 用户界面模块设计原理

用户界面利用Vue.js框架实现

### 5.3 业务逻辑层分解

业务逻辑层分解如图所示：

![image-20220710101458673](lab7-软件体系结构设计文档.assets/image-20220710101458673.png)

#### 5.3.1 职责

| 模块         | 职责                                       |
| ---------- | ---------------------------------------- |
| Finacialbl | 负责财务人员账户管理的业务<br />负责财务人员制定收款单的业务<br />负责财务人员制定付款单的业务<br />负责财务人员制定工资单的业务<br /> |
| Hrbl       | 负责人力资源人员员工管理的业务<br />负责人力资源人员员工打卡的业务<br />负责人力资源人员薪酬规则制定的业务<br /> |
| Salebl     | 负责查询销售明细表的业务<br>负责查询经营历程表的业务<br>负责查询经营情况表的业务 |
|            |                                          |



#### 5.3.2 接口规范

##### Financialbl模块的关键类图

![image-20220710101216899](lab7-软件体系结构设计文档.assets/image-20220710101216899.png)

##### Financialbl模块的接口规范

| 接口名称                                  | 语法                                       | 前置条件 | 后置条件                                     |
| ------------------------------------- | ---------------------------------------- | ---- | ---------------------------------------- |
| BankService.createBank                | createBank(Bank bank,Long id)            | 无    | 将账户信息传给BankMapper                        |
| BankService.getAllBank                | getAllBank()                             | 无    | 从BankMapper获得所有的账户                       |
| BankService.delBank                   | delBank(Long id)                         | 无    | 将要删除的账户信息传给BankMapper                    |
| ReceiptService.addReceiptSheet        | addReceiptSheet(ReceiptSheet rs)         | 无    | 将收款单信息传递给ReceiptSheetMapper              |
| ReceiptService.addReceiptSheetContent | addReceiptSheetContent(ReceiptSheetContent rsc) | 无    | 将收款单转账列表信息传递给ReceiptSheetTransferListMapper |
| ReceiptService.getReceiptSheetList    | getReceiptSheetList()                    | 无    | 从ReceiptSheetMapper获得全部的收款单信息            |
| ReceiptService.getReceiptSheetContent | getReceiptSheetContent(String rsId)      | 无    | 从ReceiptSheetTransferListMapper获得收款单转账列表信息 |
| PaymentService.addPaymentSheet        | addPaymentSheet(PaymentSheet pms)        | 无    | 将付款单信息传递给PaymentSheetMapper              |
| PaymentService.addPaymentSheetContent | addPaymentSheetContent(PaymentSheetContent pmsc) | 无    | 将付款单条目信息传递给PaymentSheetCheckListMapper   |
| PaymentService.getPaymentSheetList    | getPaymentSheetList()                    | 无    | 从PaymentSheetMapper获得全部的付款单信息            |
| PaymentService.getPaymentSheetContent | getPaymentSheetContent(String pmsId)     | 无    | 从PaymentSheetCheckListMapper获得付款单条目信息    |
| PayrollService.addPayrollSheet        | addPayrollSheet(PayrollSheet prs)        | 无    | 将工资单信息传递给PayrollSheetMapper              |
| PayrollService.getPayrollSheetList    | getPayrollSheetList()                    | 无    | 从PayrollSheetMapper获得全部的工资单信息            |
| PayWageService.paySalary              | paySalary(PayWagesStrategy strategy, Staff staff) | 无    | 从PayWagesStrategy调用对应的策略方法               |
|                                       |                                          |      |                                          |

##### Financialbl模块需要的服务

| 服务名                                      | 服务               | 备注                 |
| ---------------------------------------- | ---------------- | ------------------ |
| BankMapper.insert                        | 插入账户             | 由mybatis-plusAPI提供 |
| BankMapper.selectById                    | 根据账户ID返回账户       | 由mybatis-plusAPI提供 |
| BankMapper.updateById                    | 通过账户ID更新账户       | 由mybatis-plusAPI提供 |
| BankMapper.getAllBanks                   | 获取所有账户           | 无                  |
| BankMapper.deleteById                    | 通过账户ID删除账户       | 由mybatis-plusAPI提供 |
| ReceiptSheetMapper.insert                | 插入收款单            | 由mybatis-plusAPI提供 |
| ReceiptSheetTransferListMapper.insert    | 插入收款单转账列表信息      | 由mybatis-plusAPI提供 |
| ReceiptSheetMapper.getAllRs              | 返回全部收款单          | 无                  |
| ReceiptSheetTransferListMapper.selectList | 通过收款单ID返回收款单转账列表 | 由mybatis-plusAPI提供 |
| PaymentSheetMapper.insert                | 插入付款单            | 由mybatis-plusAPI提供 |
| PaymentSheetCheckListMapper.insert       | 插入付款单条目信息        | 由mybatis-plusAPI提供 |
| PaymentSheetMapper.getAllPms             | 返回全部付款单          | 无                  |
| PaymentSheetCheckListMapper.selectList   | 通过付款单ID返回付款单条目信息 | 由mybatis-plusAPI提供 |
| PayrollSheetMapper.insert                | 插入工资单            | 由mybatis-plusAPI提供 |
| PayrollSheetMapper.getAllPrs             | 返回全部工资单          | 无                  |
| Strategy.payWages                        | 调用对应的薪资策略        | 无                  |
|                                          |                  |                    |

##### Hrbl模块的关键类图

![image-20220708154531820](lab7-软件体系结构设计文档.assets/image-20220708154531820.png)

##### Hrbl模块的接口规范

| 接口名称                     | 语法                     | 前置条件 | 后置条件                             |
| ------------------------ | ---------------------- | ---- | -------------------------------- |
| SignInService.addSign    | addSign(SignIn signIn) | 无    | 将签到信息传给SignInRecordMapper        |
| SignInService.getSign    | getSign(String name)   | 无    | 从SignInRecordMapper获取签到信息        |
| UserService.getAllUser   | getAllUser()           | 无    | 从UserMapper获得所有的用户信息             |
| StaffService.addStaff    | addStaff(Staff staff)  | 无    | 将员工信息传给StaffMapper和UserMapper    |
| StaffService.getAllStaff | getAllStaff()          | 无    | 从StaffMapper获得所有的员工信息            |
| StaffService.deleteStaff | deleteStaff(Long id)   | 无    | 将删除的员工信息传给StaffMapper和UserMapper |

##### Hrbl模块需要的服务

| 服务名                           | 服务           | 备注                 |
| ----------------------------- | ------------ | ------------------ |
| SignInRecordMapper.selectList | 通过员工姓名返回员工   | 由mybatis-plusAPI提供 |
| SignInRecordMapper.insert     | 增加一条打卡信息     | 由mybatis-plusAPI提供 |
| signInRecordMapper.delete     | 删除一条打卡信息     | 由mybatis-plusAPI提供 |
| StaffMapper.insert            | 插入员工信息       | 由mybatis-plusAPI提供 |
| StaffMapper.selectList        | 通过员工电话返回员工   | 由mybatis-plusAPI提供 |
| UserDao.insert                | 插入用户信息       | 无                  |
| StaffMapper.updateById        | 通过员工ID更新员工信息 | 由mybatis-plusAPI提供 |
| StaffMapper.getAllStaff       | 返回全部员工信息     | 由mybatis-plusAPI提供 |
| StaffMapper.deleteById        | 通过员工ID删除员工信息 | 由mybatis-plusAPI提供 |
| UserDao.deleteById            | 通过用户ID删除用户信息 | 无                  |
| UserDao.getAllUser            | 返回全部用户信息     | 无                  |

##### salebl模块的关键类图

![image-20220709191037](lab7-软件体系结构设计文档.assets/image-20220709191037.png)

##### salebl模块的接口规范

| 接口名称                                 | 语法                                       | 前置条件 | 后置条件                                     |
| ------------------------------------ | ---------------------------------------- | ---- | ---------------------------------------- |
| SaleService.checkSaleDetail          | checkSaleDetail(SaleDetailMessage sdm)   | 无    | 将销售信息查询条件传递给SaleCheckDao                 |
| SaleService.getManageExprList        | getManageExprList（ManageExprVO manageExprVO） | 无    | 将销售历程查询信息传递给saleSheetDao和saleReturnsSheetDao |
| SaleService.getContentById           | getContentById(String id)                | 无    | 将单据id传递给saleSheetDao                     |
| SaleService.hongChong                | hongchong(id)                            | 无    | 将红冲单据id传递给saleSheetDao                   |
| SaleService.getFinalSaleMoney        | getFinalSaleMoney(Date beginTime, Date endTime) | 无    | 将总收入查询时间传递给saleSheetDao和saleReturnsSheetDao |
| SaleService.getDiscount              | getDiscount(Date beginTime, Date endTime) | 无    | 将总折让查询时间传递给saleSheetDao和saleReturnsSheetDao |
| SaleService.integrateToManageStateVO | integrateToManageStateVO(String beginTimeStr, String endTimeStr) | 无    | 将销售情况查询时间传递给SaleSheetDao,financialService,purchaseService |

##### salebl模块需要的服务

| 服务名                                      | 服务                          |
| ---------------------------------------- | --------------------------- |
| SaleSheetDao.getAllSheetExper(ManageExperVO mev) | 通过销售细节条件查询所有销售细节            |
| SaleSheetDao.getAllSaleMoneyBetween(Date beginTime, Date endTime) | 通过时间区间查询总收入                 |
| SaleReturnsSheetDao.getAllDiscountBetween(Date beginTime, Date endTime) | 通过时间区间查询总折让                 |
| SaleReturnsSheetDao.getAllSheetExper(ManageExperVO mev) | 通过销售历程条件查询销售历程              |
| SaleReturnsSheetDao.getAllSaleMoneyBetween(Date beginTime, Date endTime) | 通过时间区间查询所有退费                |
| SaleSheetDao.getAllDiscountBetween(Date beginTime, Date endTime) | 通过时间区间拆线呢所有退的折让             |
| FinancialService.getAllOutBetween(Date beginTime, Date endTime) | 通过时间区间调用financial服务查询所有财务支出 |
| FinancialService.getAllInBetween(Date beginTime, Date endTime) | 通过时间区间调用financial服务查询所有财务收入 |
| PurchaseService.getPurchaseMoney(Date beginTime, Date endTime) | 通过时间区间调用purchase服务查询进货花费    |

##### SaleStrategybl模块的关键类图

![image-20220710004941](lab7-软件体系结构设计文档.assets/image-20220710004941.png)

##### SaleStrategybl模块的接口规范

| 接口名称                                           | 语法                                                         | 前置条件 | 后置条件                                                                  |
|------------------------------------------------|------------------------------------------------------------|------|-----------------------------------------------------------------------|
| SimpleSaleStrategyImpl.createSaleStrategy      | createSaleStrategy(SaleStrategyVO saleStrategyVO)          | 无    | 将要添加的简单促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息    |
| GroupSaleStrategyImpl.createSaleStrategy       | createSaleStrategy(SaleStrategyVO saleStrategyVO)          | 无    | 将要添加的特价包促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息   |
| FillDeclineSaleStrategyImpl.createSaleStrategy | createSaleStrategy(SaleStrategyVO saleStrategyVO)          | 无    | 将要添加的满减、满送促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息 |
| SaleStrategyService.getAllSaleStrategy         | getAllSaleStrategy()                                       | 无    | 从SaleStrategyDao获取全部的促销策略信息                                           |
| SaleStrategyService.getAllGroup                | getAllGroup(String saleStrategyId)                         | 无    | 将需要查询赠品/特价包清单的促销策略id传递给GroupService                                   |
| GroupService.getAllGroup                       | getAllGroup(String saleStrategyId)                         | 无    | 将需要查询赠品/特价包清单的促销策略id传递给GroupConditionContentDao                       |
| SaleStrategyService.deleteSaleStaff            | deleteSaleStaff(String saleStrategyId)                     | 无    | 将要删除的促销策略信息传给SaleStrategyDao和GroupConditionContentDao。                |
| GiftSheetService.createGiftSheet               | createGiftSheet( String saleSheetId,String saleStrategyId) | 无    | 将要添加的赠品单信息传递给GiftSheetDao,SaleSheetDao,GroupService向表中插入相应信息          |
| GiftSheetService.getAllGiftSheet               | getAllGiftSheet()                                          | 无    | 从GiftSheetDao获取全部赠品单信息                                                |
| GiftSheetService.approval                      | approval(String giftSheetId,GiftSheetState state)          | 无    | 将赠品单信息和审批状态处理后传入GiftSheetDao,WarehouseDao中，更改相应状态                     |


##### SaleStrategybl模块需要的服务

| 服务名                                                             | 服务                           | 备注                 |
|-----------------------------------------------------------------|------------------------------|--------------------|
| SaleStrategyDao.insert                                          | 在数据库中增加一个促销策略                | 由mybatis-plusAPI提供 |
| SaleStrategyDao.getAllSaleStrategy                              | 返回所有的促销策略                    | 无                  |
| SaleStrategyDao.getSaleStrategyById                             | 返回数据相应id的促销策略                | 无                  |
| SaleStrategyDao.deleteById                                      | 删除一个促销策略                     | 由mybatis-plusAPI提供 |
| GroupConditionContentDao.insert                                 | 在数据库中增加一条详细清单                | 由mybatis-plusAPI提供 |
| GroupConditionContentDao.getAllConditionContentBySaleStrategyId | 返回相应的GroupConditionContent列表 | 无                  |
| SaleSheetDao.findSheetById                                      | 返回相应的SaleSheetPO             | 无                  |
| GiftSheetDao.saveBatch                                          | 向数据库中增加一系列详细清单               | 无                  |
| GiftSheetDao.insert                                             | 在数据库中增加一个赠品单                 | 由mybatis-plusAPI提供 |
| GiftSheetDao.getAllGiftSheetContentByGiftSheetId                | 返回相应赠品单id的GiftSheetContent列表 | 无                  |
| GiftSheetDao.getGiftSheetById                                   | 返回相应id的GiftSheetPO           | 无                  |
| GiftSheetDao.getAllGiftSheet                                    | 返回所有赠品单列表                    | 无                  |
##### Initbl的关键类图
![image-20220710102312294](lab7-软件体系结构设计文档.assets/image-20220710102312294.png)

Initbl模块的接口规范

| 接口名称                                  | 语法                                | 前置条件 | 后置条件                               |
|---------------------------------------|-----------------------------------|------|------------------------------------|
| InitialInfoService.init               | init()                            | 无    | 使InitialInfoService执行期初建账函数init()。 |
| InitialInfoService.getAllInitCategory | getAllInitCategory(String initId) | 无    | 将建账套数initId信息传入InitialInfoService  |
| InitialInfoService.getAllInitProduct  | getAllInitProduct(String initId)  | 无    | 将建账套数initId信息传入InitialInfoService  |
| InitialInfoService.getAllInitBank     | getAllInitBank(String initId)     | 无    | 将建账套数initId信息传入InitialInfoService  |
| InitialInfoService.getAllInitCustomer | getAllInitCustomer(String initId) | 无    | 将建账套数initId信息传入InitialInfoService  |


##### **Init模块的服务服务接口**

| 服务名                                                  | 服务                                                                                                                                    |
|------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| InitialInfoService.init()                            | 从CategoryDao,BankDao,ProductDao,CustomerDao中取出当前数据,向InitMapper,CategoryMapper,BankMapper,ProductMapper,CustomerMapper中插入当前数据，进行期初建账活动 |
| InitialInfoService.getAllInitCategory(String initId) | 向InitCategoryMapper中传入initId数据，得到这套账的所有商品类别信息。                                                                                        |
| InitialInfoService.getAllInitProduct(String initId)  | 向InitProductMapper中传入initId数据，得到这套账的所有商品类别信息。                                                                                         |
| InitialInfoService.getAllInitBank(String initId)     | 向InitBankMapper中传入initId数据，得到这套账的所有商品类别信息。                                                                                            |
| InitialInfoService.getAllInitCustomer(String initId) | 向InitCustomerMapper中传入initId数据，得到这套账的所有商品类别信息。|
##### Initbl模块需要的服务

| 服务名                               | 服务         | 备注                 |
|-----------------------------------|------------|--------------------|
| CategoryDao.findAll               | 获得当前所有类别信息 | 无                  |
| ProductDao.findAll                | 获得当前所有商品信息 | 无                  |
| BankDao.findAll                   | 获得当前所有银行信息 | 无                  |
| CustomerDao.findAll               | 获得当前所有客户信息 | 无                  |
| initCategoryMapper.insert         | 插入期初类别信息   | 由mybatis-plusAPI提供 |
| initProductMapper.insert          | 插入期初产品信息   | 由mybatis-plusAPI提供 |
| initBankMapper.insert             | 插入期初银行信息   | 由mybatis-plusAPI提供 |
| initCustomerMapper.insert         | 插入期初客户信息   | 由mybatis-plusAPI提供 |
| initCategoryMapper.getAllByInitId | 获得期初类别信息   | 无                  |
| initProductMapper.getAllByInitId  | 获得期初产品信息   | 无                  |
| initBankMapper.getAllByInitId     | 获得期初银行信息   | 无                  |
| initCustomerMapper.getAllByInitId | 获得期初客户信息   | 无                  |




### 5.4 数据层分解

数据层主要给业务逻辑层提供数据访问服务，包括对持久化数据的增、删、改、查等。其中Finacial模块所需要的服务BankMapper,ReceiptSheetMapper,ReceiptSheetTransferListMapper,PaymentSheetMapper,PaymentSheetCheckListMapper,PayrollSheetMapper提供，Hr模块所需要的服务由SignInRecordMapper,StaffMapper,UserMapper提供.Sale模块需要的服务，由SaleSheetDao,SaleReturnsSheetDao,SaleCheckDao提供。

![image-20220710101248458](lab7-软件体系结构设计文档.assets/image-20220710101248458.png)

#### 5.4.1 职责

数据层模块的职责如下表所示。

| 模块                             | 职责                                     |
| ------------------------------ | -------------------------------------- |
| BankDao                        | 持久化数据库的接口。提供账户信息的载入、保存、增、删、改、查服务。      |
| ReceiptSheetMapper             | 持久化数据库的接口。提供收款单信息的载入、保存、增、删、改、查服务。     |
| ReceiptSheetTransferListMapper | 持久化数据库的接口。提供收款单转账列表信息的载入、保存、增、删、改、查服务。 |
| PaymentSheetMapper             | 持久化数据库的接口。提供付款单信息的载入、保存、增、删、改、查服务。     |
| PaymentSheetCheckListMapper    | 持久化数据库的接口。提供付款单条目信息的载入、保存、增、删、改、查服务。   |
| PayrollSheetMapper             | 持久化数据库的接口。提供工资单信息的载入、保存、增、删、改、查服务。     |
| SignInRecordMapper             | 持久化数据库的接口。提供打卡信息的增、查服务。                |
| StaffMapper                    | 持久化数据库的接口。提供职工信息的载入、保存、增、删、改、查服务。      |
| UserDao                        | 持久化数据库的接口。提供用户信息的载入、保存、增、删、改、查服务。      |
| SaleSheetDao                   | 持久化数据库的接口。提供销售信息的载入、保存、增、删、改、查服务       |
| SaleReturnsSheetDao            | 持久化数据库的接口。提供销售退货信息的载入、保存、增、删、改、查       |
| SaleCheckDao                   | 持久化数据库的接口。提供销售细节的载入、保存、增、删、改、查         |
| SaleStrategyDao                | 持久化数据库的接口。提供促销策略信息的载入、保存、增、删、改、查服务。           |
| GroupConditionContentDao       | 持久化数据库的接口。提供促销策略赠品/特价包详细清单信息的载入、保存、增、删、改、查服务。 |
| GiftSheetDao                   | 持久化数据库的接口。提供赠品单信息的载入、保存、增、删、改、查服务。            |
| initCategoryMapper             | 持久化数据库的接口。提供用期初类别信息的载入、保存、增、删、改、查服务。          |
| initProductMapper              | 持久化数据库的接口。提供用期初产品信息的载入、保存、增、删、改、查服务。          |
| initBankMapper                 | 持久化数据库的接口。提供用期初银行信息的载入、保存、增、删、改、查服务。          |
| initCustomerMapper             | 持久化数据库的接口。提供用期初客户信息的载入、保存、增、删、改、查服务。          |
| CategoryDao                    | 持久化数据库的接口。提供用类别信息的载入、保存、增、删、改、查服务。            |
| ProductDao                     | 持久化数据库的接口。提供用产品信息的载入、保存、增、删、改、查服务。            |
| BankDao                        | 持久化数据库的接口。提供用银行信息的载入、保存、增、删、改、查服务。            |
| CustomerDao                    | 持久化数据库的接口。提供用客户信息的载入、保存、增、删、改、查服务。            |


#### 5.4.2 接口规范

由于部分模块采用了mybatis-plus技术，部分方法的具体实现已由该框架API本身提供，可参考业务逻辑层部分相关说明。

| 接口名称                                     | 语法                                       | 前置条件              | 后置条件                  |
| ---------------------------------------- | ---------------------------------------- | ----------------- | --------------------- |
| BankDao.insert                           | int insert(T entity)                     | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| BankDao.selectById                       | T selectById(Serializable id)            | 无                 | 按ID查找返回相应的entity      |
| BankDao.updateById                       | int updateById(T entity)                 | 数据库中存在相同ID的entity | 更新一个entity            |
| BankDao.getAllBanks                      | List\<Bank> getAllBanks()                | 无                 | 返回相应的entity           |
| BankDao.deleteById                       | int deleteById(Serializable id)          | 数据库中存在相同ID的entity | 删除一个entity            |
| ReceiptSheetMapper.insert                | int insert(T entity)                     | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| ReceiptSheetTransferListMapper.insert    | int insert(T entity)                     | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| ReceiptSheetMapper.getAllRs              | List\<ReceiptSheet> getAllRs()           | 无                 | 返回相应的entity           |
| ReceiptSheetTransferListMapper.selectList | List\<T> selectList( Wrapper\<T> queryWrapper) | 无                 | 按wrapper查找返回相应的entity |
| PaymentSheetMapper.insert                | int insert(T entity)                     | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| PaymentSheetCheckListMapper.insert       | int insert(T entity)                     | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| PaymentSheetMapper.getAllPms             | List\<PaymentSheet> getAllPms()          | 无                 | 返回相应的entity           |
| PaymentSheetCheckListMapper.selectList   | List\<T> selectList( Wrapper\<T> queryWrapper) | 无                 | 按wrapper查找返回相应的entity |
| PayrollSheetMapper.insert                | int insert(T entity)                     | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| PayrollSheetMapper.getAllPrs             | List\<PayrollSheet> getAllPrs()          | 无                 | 返回相应的entity           |
| //空行区分模块                 |                                          |                   |                       |
| SignInRecordMapper.selectList            | List\<T> selectList( Wrapper\<T> queryWrapper) | 无                 | 按wrapper查找返回相应的entity |
| SignInRecordMapper.insert                | int insert(T entity)                     | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| SignInRecordMapper.delete                | int delete(Wrapper\<T> queryWrapper)     | 数据库中存在对应的entity   | 按wrapper删除相应的entity信息 |
| StaffMapper.insert                       | int insert(T entity)                     | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| StaffMapper.selectList                   | List\<T> selectList( Wrapper\<T> queryWrapper) | 无                 | 按wrapper查找返回相应的entity |
| StaffMapper.updateById                   | int updateById(T entity)                 | 数据库中存在相同ID的entity | 更新一个entity            |
| StaffMapper.getAllStaff                  | List\<Staff> getAllStaff();              | 无                 | 返回相应的entity           |
| StaffMapper.deleteById                   | int deleteById(Serializable id)          | 数据库中存在相同ID的entity | 删除一个entity            |
| UserDao.createUser                       | int createUser(User user)                | 数据库中不存在相同的entity  | 在数据库中增加一个entity       |
| UserDao.deleteById                       | void deleteById(Integer id)              | 数据中存在相同ID的entity  | 删除一个entity            |
| UserDao.getAllUser                       | List\<User> getAllUser()                 | 无                 | 返回相应的entity           |
| SaleCheckDao.checkSaleDetail             | List<SaleDetailPO> checkSaleDetail(SaleDetailMessage sdm); | 无                 | 返回相应的实体列表             |
| SaleSheetDao.getAllSheetExpr             | List<SaleSheetPO> getAllSheetExpr(ManageExprVO exprVO); | 无                 | 返回相应的实体列表             |
| SaleSheetDao.getAllDiscountBetween       | Integer getAllSaleMoneyBetween(Date beginTime, Date endTime); | 无                 | 返回一段时间内总收入            |
| SaleSheetDao.getAllSaleMoneyBetween      | Integer getAllDiscountBetween(Date beginTime, Date endTime); | 无                 | 返回一段时间内的总折让           |
| SaleReturnsSheetDao.getAllSheetExpr      | List<SaleReturnsSheetPO> getAllSheetExpr(ManageExprVO exprVO); | 无                 | 返回相应的实体列表             |
| SaleReturnsSheetDao.getAllDiscountBetween | Integer getAllSaleReturnMoneyBetween(Date beginTime, Date endTime); | 无                 | 返回一段时间内总退货收入          |
| SaleReturnsSheetDao.getAllSaleMoneyBetween | Integer getAllDiscountReturnBetween(Date beginTime, Date endTime); | 无                 | 返回一段时间内的总退货折让         |
| //空行区分模块                                                        |                                                                                           |                           |                              |
| SaleStrategyDao.insert                                          | int insert(T entity)                                                                      | 数据中不存在相同ID的entity         | 在数据库中增加一个entity              |
| SaleStrategyDao.getAllSaleStrategy                              | List<SaleStrategyPO> getAllSaleStrategy()                                                 | 无                         | 返回所有的数据                      |
| SaleStrategyDao.getSaleStrategyById                             | SaleStrategyPO getSaleStrategyById(String id)                                             | 数据存在相同id的entity           | 返回数据相应id的entity              |
| SaleStrategyDao.deleteById                                      | int deleteById(Serializable id)                                                           | 数据中存在相同ID的entity          | 删除一个entity                   |
| GroupConditionContentDao.insert                                 | int insert(T entity)                                                                      | 数据中不存在相同ID的entity         | 在数据库中增加一个entity              |
| GroupConditionContentDao.getAllConditionContentBySaleStrategyId | List<GroupConditionContent> getAllConditionContentBySaleStrategyId(String saleStrategyId) | 数据中存在有相同saleStrategyId的数据 | 返回相应的GroupConditionContent列表 |
| SaleSheetDao.findSheetById                                      | SaleSheetPO findSheetById(String id)                                                      | 数据中存在有相同id的数据             | 返回相应的SaleSheetPO             |
| GiftSheetDao.saveBatch                                          | void saveBatch(List<GiftSheetContentPO> giftSheetContentPOList)                           | 无                         | 向数据库中增加列表中的数据项               |
| GiftSheetDao.insert                                             | int insert(T entity)                                                                      | 数据中不存在相同ID的entity         | 在数据库中增加一个entity              |
| GiftSheetDao.getAllGiftSheetContentByGiftSheetId                | List<GiftSheetContentPO> getAllGiftSheetContentByGiftSheetId(String giftSheetId)          | 数据中存在相同giftSheetId的数据     | 返回相应的GiftSheetContent列表      |
| GiftSheetDao.getGiftSheetById                                   | GiftSheetPO getGiftSheetById(String id)                                                   | 数据中存在有相同id的数据             | 返回相应的GiftSheetPO             |
| GiftSheetDao.getAllGiftSheet                                    | List<GiftSheetPO> getAllGiftSheet()                                                       | 无                         | 返回所有赠品单列表                    |
| //空一行区分模块                                                       |                                                                                           |                           |                              |
| CategoryDao.findAll                                             | List<CategoryPO> findAll()                                                                | 无                         | 返回当前所有的类别信息                  |
| ProductDao.findAll                                              | List<ProductPO> findAll()                                                                 | 无                         | 返回当前所有的产品信息                  |
| CustomerDao.findAll                                             | List<CustomerPO> findAll()                                                                | 无                         | 返回当前所有客户信息                   |
| BankDao.getAllBanks                                             | List<Bank> getAllBanks()                                                                  | 无                         | 返回当前所有的银行信息                  |
|                                                                 ||||
## 6 信息视角

### 6.1 Bank

| 属性    | 定义   | 类型         |
| ----- | ---- | ---------- |
| id    | 账户id | Long       |
| name  | 账户名称 | String     |
| money | 账户金额 | BigDecimal |

### 6.2 ReceiptSheet

| 属性         | 定义      | 类型                |
| ---------- | ------- | ----------------- |
| id         | 单据编号    | String            |
| customerId | 关联的客户id | Long              |
| remark     | 备注      | String            |
| operator   | 操作员     | String            |
| sum        | 总额汇总    | Integer           |
| state      | 单据状态    | ReceiptSheetState |

### 6.3 ReceiptSheetContent

| 属性     | 定义         | 类型      |
| ------ | ---------- | ------- |
| id     | 转账列表id     | Long    |
| skId   | 关联的收款单单据编号 | String  |
| bankId | 关联的账户id    | Long    |
| money  | 转账金额       | Integer |
| remark | 备注         | String  |

### 6.4 PaymentSheet

| 属性       | 定义      | 类型                |
| -------- | ------- | ----------------- |
| id       | 单据编号    | String            |
| bank     | 关联的账户id | Long              |
| remark   | 备注      | String            |
| operator | 操作员     | String            |
| sum      | 总额      | Integer           |
| state    | 单据状态    | PaymentSheetState |

### 6.5 PaymentSheetContent

| 属性          | 定义       | 类型      |
| ----------- | -------- | ------- |
| id          | 条目清单id   | Long    |
| customer_id | 关联的账户id  | Long    |
| fkId        | 关联的付款单id | String  |
| name        | 条目名      | String  |
| money       | 金额       | Integer |
| remark      | 备注       | String  |

### 6.6 Sign_In

| 属性       | 定义     | 类型     |
| -------- | ------ | ------ |
| id       | 打卡记录id | Long   |
| name     | 员工姓名   | String |
| signDate | 打卡时间   | Date   |

### 6.7 Staff

| 属性      | 定义   | 类型      |
| ------- | ---- | ------- |
| id      | 员工id | Long    |
| name    | 员工姓名 | String  |
| sex     | 员工性别 | String  |
| age     | 员工年龄 | Integer |
| phone   | 电话号码 | String  |
| post    | 岗位   | Integer |
| salMon  | 月薪   | Integer |
| salYear | 年薪   | Integer |
| upSal   | 提成比例 | Double  |
| bank    | 银行账户 | String  |
| salType | 薪资类型 | Integer |

### 6.8 SaleStrategy

| 属性             | 定义   | 类型         |
|----------------|------|------------|
| id             | 策略id | String     |
| type           | 策略类型 | int        |
| name           | 策略名称 | String     |
| discount       | 策略折扣 | BigDecimal |
| voucher        | 策略抵扣 | BigDecimal |
| realTotalPrice | 满减标准 | BigDecimal |
| createDate     | 创建时间 | Date       |

### 6.9 GroupConditionContent
| 属性             | 定义      | 类型                 |
|----------------|---------|--------------------|
| saleStrategyId | 关联的策略id | String             |
| pid            | 策略类型    | String             |
| quantity       | 策略名称    | Integer            |
| unitPrice      | 策略折扣    | BigDecimal         |

### 6.10 GiftSheet

| 属性          | 定义       | 类型             |
|-------------|----------|----------------|
| id          | 赠品单id    | String         |
| saleSheetId | 关联的销售单id | String         |
| supplier    | 客户id     | Integer        |
| operator    | 操作员      | BigDecimal     |
| createDate  | 创建时间     | Date           |
| state       | 赠品单状态    | GiftSheetState |

### 6.11 GiftSheetContent
| 属性          | 定义       | 类型      |
|-------------|----------|---------|
| id          | 自增id     | Integer |
| giftSheetId | 关联的赠品单id | String  |
| pid         | 商品id     | String  |
| quantity    | 数量       | Integer |

### 6.12 SaleDetail

| 属性          | 定义   | 类型      |
| ----------- | ---- | ------- |
| saleDate    | 员工id | Long    |
| productName | 员工姓名 | String  |
| productType | 员工性别 | String  |
| saleNum     | 员工年龄 | Integer |
| unitPrice   | 电话号码 | String  |
| totalPrice  | 岗位   | Integer |