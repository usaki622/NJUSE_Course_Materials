# lab7-软件详细设计文档模块

## 文档修改历史

| 修改人员 | 日期      | 修改原因                                                     | 版本号 |
| -------- | --------- | ------------------------------------------------------------ | ------ |
| 姚天翔   | 2022.6.29 | 完成软件详细设计文档整体框架，并完成财务模块和人力资源模块部分初步设计 | V1.0   |
| 练健恒   | 2022.6.30 | 添加销售模块部分                                             | V1.1   |
| 罗瑞航   | 2022.6.30 | 添加促销模块部分                                             | v1.2   |
| 姚天翔   | 2022.7.9  | 进行了细节的修改，对文档进行了完善                           | V1.3   |
|          |           |                                                              |        |

## 1 引言

### 1.1 编制目的

本报告详细完成对ERP系统部分模块的详细设计，以达到指导详细设计和开发的目的，同时实现和测试人员以及用户的沟通。

本报告面向开发人员、测试人员及最终用户而编写，是了解系统的导航。

### 1.2 词汇表

| 词汇名称 | 词汇含义 | 备注   |
| ---- | ---- | ---- |
|      |      |      |

### 1.3 参考资料

(1)IEEE标准

(2)《软件工程与计算（卷二） 软件开发的技术基础》丁二玉、刘钦著

(3)ERP系统需求规格说明文档

(4)ERP系统软件体系结构文档

## 2 产品概述

此部分请参考ERP系统用例文档和软件需求规格说明文档中对产品的概括描述。

## 3 体系结构设计概述

此部分请参考ERP系统的体系结构设计文档中对体系结构设计的描述

## 4 结构视角

### 4.1 业务逻辑层的分解

业务逻辑层的开发包参见软件体系结构文档。

#### 4.1.1 Financialbl模块

##### (1)模块概述

Financialbl模块承担的需求参见需求规格说明文档功能需求及相关非功能需求说明文档。

Financialbl模块的职责及接口参见软件系统结构描述文档。

##### (2)整体结构

根据体系结构的设计，我们将系统分为了前端展示层、Controller层、业务逻辑层、数据层。每一层为了增加灵活性，我们会添加接口。例如，展示层和业务逻辑层之间，我们设置了Service接口。业务逻辑层和数据层之间设置了Mapper接口，且部分接口采用了Mybatis Plus技术。相关的Entity是作为与该模块相关的持久化对象而添加的设计模型中的。

**Financialbl模块的设计如下图：**

![image-20220710101628557](lab7-详细设计文档.assets/image-20220710101628557.png)

**各个类的职责：**

| 模块                             | 职责                                 |
| ------------------------------ | ---------------------------------- |
| BankController                 | 负责账户管理相关功能的前后端交互                   |
| PaymentController              | 负责付款单制定相关功能的前后端交互                  |
| PayrollController              | 负责工资单制定相关功能的前后端交互                  |
| ReceiptController              | 负责收款单制定相关功能的前后端交互                  |
| PaywageControlller             | 负责薪资策略调用相关功能的前后端交互                 |
|                                |                                    |
| BankService                    | 负责实现账户管理相关功能，如增删改查等                |
| PaymentService                 | 负责实现付款单制定相关功能，如增删改查等               |
| PayrollService                 | 负责实现工资单制定相关功能，如增删改查等               |
| ReceiptService                 | 负责实现收款单制定相关功能，如增删改查等               |
| PaywageService                 | 负责实现薪资策略调用相关功能                     |
|                                |                                    |
| BankDao                        | 负责为账户管理相关功能提供数据层访问服务               |
| ReceiptSheetMapper             | 负责为收款单相关功能提供数据层访问服务                |
| ReceiptSheetTransferListMapper | 负责为收款单转账列表相关功能提供数据层访问服务            |
| PaymentSheetMapper             | 负责为付款单相关功能提供数据层访问服务                |
| PaymentSheetCheckListMapper    | 负责为付款单条目清单相关功能提供数据层访问服务            |
| PayrollSheetMapper             | 负责为工资单相关功能提供数据层访问服务                |
|                                |                                    |
| Strategy                       | 负责实现不同的薪资策略                        |
| Bank                           | 负责账户相关功能的实现载体，存有账户名称、金额等信息         |
| ReceiptSheet                   | 负责收款单相关功能的实现载体，存有单据编号、客户id、操作员等信息  |
| ReceiptSheetTransferList       | 负责收款单转账列表相关功能的实现载体，存有银行金额、转账账户等信息  |
| PaymentSheet                   | 负责付款单相关功能的实现载体，存有单据编号、操作员、银行账户等信息  |
| PaymentSheetCheckList          | 负责付款单条目清单相关功能的实习现在提，存有条目名、金额、备注等信息 |
| PayrollSheet                   | 负责工资单相关功能的实现载体，存有单据编号、员工编号、工资等信息   |
|                                |                                    |



##### (3)模块内部类的接口规范

Financialbl模块的各个类的职责和内部类的接口规范已在ERP系统体系结构设计文档中描述。

##### **Financial模块的接口规范**

| 接口名称                                     | 语法                                     | 前置条件 | 后置条件                                |
| ---------------------------------------- | -------------------------------------- | ---- | ----------------------------------- |
| BankController.createOrUpdateBank        | createOrUpdateBank(JSONObject obj)     | 输入合法 | 将账户信息传递给后端BankService               |
| BankController.deleteBank                | deleteBank(JSONObject obj)             | 输入合法 | 将被删除的账户信息传递给后端BankService           |
| BankController.getAllBank                | getAllBank()                           | 无    | 从BankService获得全部的账户信息               |
| ReceiptController.addReceiptSheet        | addReceiptSheet(JSONObject obj)        | 输入合法 | 将收款单信息传递给后端ReceiptService           |
| ReceiptController.addReceiptSheetContent | addReceiptSheetContent(JSONObject obj) | 输入合法 | 将收款单转账列表信息传递给后端ReceiptService       |
| ReceiptController.getAllReceiptSheet     | getAllReceiptSheet()                   | 无    | 从ReceiptService获得全部的收款单信息           |
| PaymentController.addPaymentSheet        | addPaymentSheet(JSONObject obj)        | 输入合法 | 将付款单信息传递给后端PaymentService           |
| PaymentController.addPaymentSheetContent | addPaymentSheetContent(JSONObject obj) | 输入合法 | 将付款单条目信息传递给后端PaymentService         |
| PaymentController.getAllPaymentSheet     | getAllPaymentSheet()                   | 无    | 从PaymentService获得全部的付款单信息           |
| PayrollController.getAllPayrollSheet     | getAllPayrollSheet()                   | 无    | 从PayrollService获得全部的工资单信息           |
| PayrollController.addPayrollSheet        | addPayrollSheet(JSONObject obj)        | 输入合法 | 将工资单信息传递给后端PayrollService           |
| PayWageController.PayWage                | PayWage(Staff staff)                   | 输入合法 | 将staff相关信息传递给payWageService，调用对应的策略 |
|                                          |                                        |      |                                     |

##### **Financial模块的服务接口**

| 服务名                                      | 服务                                       |
| ---------------------------------------- | ---------------------------------------- |
| BankService.createBank(Bank bank,Long id) | 将账户信息传给BankMapper                        |
| BankService.getAllBank()                 | 从BankMapper获得所有的账户                       |
| BankService.delBank(Long id)             | 将要删除的账户信息传给BankMapper                    |
| ReceiptService.addReceiptSheet(ReceiptSheet rs) | 将收款单信息传递给ReceiptSheetMapper              |
| ReceiptService.addReceiptSheetContent(ReceiptSheetContent rsc) | 将收款单转账列表信息传递给ReceiptSheetTransferListMapper |
| ReceiptService.getReceiptSheetList()     | 从ReceiptSheetMapper获得全部的收款单信息            |
| ReceiptService.getReceiptSheetContent(String rsId) | 从ReceiptSheetTransferListMapper获得收款单转账列表信息 |
| PaymentService.addPaymentSheet(PaymentSheet pms) | 将付款单信息传递给PaymentSheetMapper              |
| PaymentService.addPaymentSheetContent(PaymentSheetContent pmsc) | 将付款单条目信息传递给PaymentSheetCheckListMapper   |
| PaymentService.getPaymentSheetList()     | 从PaymentSheetMapper获得全部的付款单信息            |
| PaymentService.getPaymentSheetContent(String pmsId) | 从PaymentSheetCheckListMapper获得付款单条目信息    |
| PayrollService.addPayrollSheet(PayrollSheet prs) | 将工资单信息传递给PayrollSheetMapper              |
| PayrollService.getPayrollSheetList()     | 从PayrollSheetMapper获得全部的工资单信息            |
| PayWageService.paySalary(PayWagesStrategy strategy, Staff staff) | 从PayWagesStrategy调用对应的策略方法               |
|                                          |                                          |
|                                          |                                          |

##### (4)业务逻辑层的动态模型

下图表明了在ERP系统中，Financial.createBank的相关对象之间的协作。

![image-20220708153400421](lab7-详细设计文档.assets/image-20220708153400421.png)

下图表明了在ERP系统中，Financial.deleteBank的相关对象之间的协作。

![image-20220708153418776](lab7-详细设计文档.assets/image-20220708153418776.png)

下图表明了在ERP系统中，Financial.getAllBanks的相关对象之间的协作。

![image-20220708153429320](lab7-详细设计文档.assets/image-20220708153429320.png)

下图表明了在ERP系统中，Financial.addReceiptSheet的相关对象之间的协作。

![image-20220708153439940](lab7-详细设计文档.assets/image-20220708153439940.png)

下图表明了在ERP系统中，Financial.addReceiptSheetContent的相关对象之间的协作。

![image-20220708153452090](lab7-详细设计文档.assets/image-20220708153452090.png)

下图表明了在ERP系统中，Financial.getAllReceiptSheet的相关对象之间的协作。

***![image-20220708153507045](lab7-详细设计文档.assets/image-20220708153507045.png)***

下图表明了在ERP系统中，Financial.addPaymentSheet的相关对象之间的协作。

![image-20220708153519091](lab7-详细设计文档.assets/image-20220708153519091.png)

下图表明了在ERP系统中，Financial.addPaymentSheetContent的相关对象之间的协作。

![image-20220708153530397](lab7-详细设计文档.assets/image-20220708153530397.png)

下图表明了在ERP系统中，Financial.getAllPaymentSheet的相关对象之间的协作。

![image-20220708153542411](lab7-详细设计文档.assets/image-20220708153542411.png)

下图表明了在ERP系统中，Financial.addPayrollSheet的相关对象之间的协作。

***![image-20220708153559015](lab7-详细设计文档.assets/image-20220708153559015.png)***

下图表明了在ERP系统中，Financial.getAllPayrollSheet的相关对象之间的协作。

![image-20220708153616622](lab7-详细设计文档.assets/image-20220708153616622.png)

下图表明了在ERP系统中，Financial.PayWage的相关对象之间的协作。

***![image-20220708153630253](lab7-详细设计文档.assets/image-20220708153630253.png)***

##### (5)业务逻辑层的实现原理

利用委托式控制风格，每个界面需要访问的业务逻辑由各自的控制器委托给不同的领域对象。



#### 4.1.2 Hrbl模块

##### (1)模块概述

Hrbl模块承担的需求参见需求规格说明文档功能需求及相关肺功能需求说明文档。

Hrbl模块的职责及接口参见软件系统结构描述文档。

##### (2)整体结构

根据体系结构的设计，我们将系统分为了前端展示层、Controller层、业务逻辑层、数据层。每一层为了增加灵活性，我们会添加接口。例如，展示层和业务逻辑层之间，我们设置了Service接口。业务逻辑层和数据层之间设置了Mapper接口，且部分接口采用了Mybatis Plus技术。相关的Entity是作为与该模块相关的持久化对象而添加的设计模型中的。

**Hrbl模块的设计如下图：**

![image-20220708154503604](lab7-详细设计文档.assets/image-20220708154503604.png)

**各个类的职责：**

| 模块                 | 职责                                  |
| ------------------ | ----------------------------------- |
| HrController       | 负责人力资源人员相关功能的前后端交互                  |
| SignInService      | 负责实现员工打卡相关功能                        |
| StaffService       | 负责实现员工管理相关功能，如增删查等                  |
| SignInRecordMapper | 负责为员工打卡相关功能提供数据层访问服务                |
| StaffMapper        | 负责为员工管理相关功能提供数据层访问服务                |
| UserDao            | 负责为用户相关功能提供数据层访问服务                  |
| SignIn             | 负责员工打卡相关功能的实现载体，存有打卡记录，员工姓名，打卡时间等信息 |
| Staff              | 负责职工相关功能的实现载体，存有员工姓名，电话号码等信息        |
| User               | 负责用户相关功能的实现载体，存有用户ID等信息             |

##### (3)模块内部类的接口规范

Hrbl模块的各个类的职责和内部类的接口规范已在ERP系统体系结构设计文档中描述。

##### **Hr模块的接口规范**

| 接口名称                     | 语法                           | 前置条件 | 后置条件                       |
| ------------------------ | ---------------------------- | ---- | -------------------------- |
| HrController.signIn      | signIn(JSONObject obj)       | 输入合法 | 将打卡信息传递给后端SignInService    |
| HrController.createStaff | createStaff(JSONObject obj)  | 输入合法 | 将员工信息传递给后端StaffService     |
| HrController.getAllStaff | getAllStaff()                | 无    | 从StaffService获得全部的员工信息     |
| HrController.deleteStaff | deleteStaff(JSONObject data) | 输入合法 | 将被删除的员工信息传递给后端StaffService |

##### **Hr模块的服务接口**

| 服务名                                  | 服务                                |
| ------------------------------------ | --------------------------------- |
| SignInService.addSign(SignIn signIn) | 将员工打卡信息传给SignInRecordMapper       |
| SignInService.getSign(String name)   | 从signInRecordMapper获取员工打卡信息       |
| UserService.getAllUser(User user)    | 从UserDao获取全部的用户信息                 |
| StaffService.addStaff(Staff staff)   | 将员工信息传给StaffMapper和UserMapper     |
| StaffService.getAllStaff()           | 从StaffMapper获取全部的员工信息             |
| StaffService.deleteStaff(Long id)    | 将要删除的员工信息传给StaffMapper和UserMapper |

##### (4)业务逻辑层的动态模型

下图表明了在ERP系统中，Hr.signIn的相关对象之间的协作。

![image-20220708162419607](lab7-详细设计文档.assets/image-20220708162419607.png)

下图表明了在ERP系统中，Hr.createStaff的相关对象之间的协作。

![image-20220708164301477](lab7-详细设计文档.assets/image-20220708164301477.png)

下图表明了在ERP系统中，Hr.getAllStaff的相关对象之间的协作。

![image-20220708164759956](lab7-详细设计文档.assets/image-20220708164759956.png)

下图表明了在ERP系统中，Hr.deleteStaff的相关对象之间的协作。

![image-20220708164531420](lab7-详细设计文档.assets/image-20220708164531420.png)

##### (5)业务逻辑层的实现原理

利用委托式控制风格，每个界面需要访问的业务逻辑由各自的控制器委托给不同的领域对象。

#### 4.1.3 Salebl模块

##### (1)模块概述

Salebl模块承担的需求参见需求规格说明文档功能需求及相关非功能需求说明文档。

Salebl模块的职责及接口参见软件系统结构描述文档。

##### (2)整体结构

根据体系结构的设计，我们将系统分为了前端展示层、Controller层、业务逻辑层、数据层。每一层为了增加灵活性，我们会添加接口。例如，展示层和业务逻辑层之间，我们设置了Service接口。业务逻辑层和数据层之间设置了Dao接口。

**Salebl模块的设计如下图：**

![image-20220709192528](lab7-详细设计文档.assets/image-20220709192528.png)

**各个类的职责：**

| 模块                      | 职责                                |
| ----------------------- | --------------------------------- |
| SaleController          | 负责账户管理相关功能的前后端交互                  |
| SaleReturnsCtroller     |                                   |
|                         |                                   |
| SaleService             | 负责实现账户管理相关功能，如增删改查等               |
| SaleReturnsService      |                                   |
| SaleSheetDao            | 负责为账户管理相关功能提供数据层访问服务              |
| SaleReturnsDao          | 负责为收款单相关功能提供数据层访问服务               |
| SaleCheckDao            | 负责为收款单转账列表相关功能提供数据层访问服务           |
|                         |                                   |
| SaleSheet               | 负责实现不同的薪资策略                       |
| SaleSheetContent        | 负责账户相关功能的实现载体，存有账户名称、金额等信息        |
| SaleReturnsSheet        | 负责收款单相关功能的实现载体，存有单据编号、客户id、操作员等信息 |
| SaleReturnsSheetContent | 负责收款单转账列表相关功能的实现载体，存有银行金额、转账账户等信息 |
|                         |                                   |



##### (3)模块内部类的接口规范

Salelbl模块的各个类的职责和内部类的接口规范已在ERP系统体系结构设计文档中描述。

##### **Sale模块的接口规范**

| 接口名称                             | 语法                                       | 前置条件 | 后置条件                                     |
| -------------------------------- | ---------------------------------------- | ---- | ---------------------------------------- |
| SaleController.checkSaleDetail   | checkSaleDetail(SaleDetailMessage sdm)   | 输入合法 | 将销售信息查询条件传递给后端PaymentService             |
| SaleController.getManageExprList | getManageExprList（ManageExprVO manageExprVO） | 输入合法 | 将销售历程查询信息传递给后端PaymentService             |
| SaleController.getContentById    | getContentById(String id)                | 输入合法 | 从SaleShhetService、SaleReturnsSheetService销售单中得到销售单的内容 |
| SaleController.hongChong         | hongchong(id)                            | 输入合法 | 向saleService传送红冲的单据id                    |
| SaleController.manageState       | manageState(String beginTime, String endTime) | 输入合法 | 将经营状况查询时间传给saleService                   |
|                                  |                                          |      |                                          |
|                                  |                                          |      |                                          |

##### **Sale模块的服务接口**

| 服务名                                      | 服务                                       |
| ---------------------------------------- | ---------------------------------------- |
| SaleService.checkSaleDetail(SaleDetailMessage sdm) | 将销售细节查询信息传递给SaleDao                      |
| SaleService.getManageExpr(ManageExprVo mev) | 将经营历程信息传递给SaleSheetDao和SaleReturnsSheetDao |
| SaleService.getSaleSheetContentById(String id) | 将销售单据的id传递给saleSheetDao                  |
| SaleReturnsService.getSaleReturnsContentById(String id) | 将销售退货单据的id传递给saleSheetDao                |
| SaleService.hongchong(String id)         | 将红冲单据id传递给saleSheeDao                    |
| SaleReturnsService.hongchong(String id)  | 将红冲单据id传递给saleReturnsSheeDao             |
| saleService.integrateToManageStateVO(Date beginTime, Date endTime) | 将开始日期和结束日期传递给saleSheetDao                |

##### (4)业务逻辑层的动态模型

下图表明了在ERP系统中，Sale.checkSaleDetail的相关对象之间的协作。

![image-20220709201622](lab7-详细设计文档.assets/image-20220709201622.png)

下图表明了在ERP系统中，Sale.getManageExprList的相关对象之间的协作。

![image-20220709201651](lab7-详细设计文档.assets/image-20220709201651.png)

下图表明了在ERP系统中，Sale.getContentById的相关对象之间的协作。

![image-20220709201710](lab7-详细设计文档.assets/image-20220709201710.png)

下图表明了在ERP系统中，Sale.hongchong的相关对象之间的协作。

![image-20220709201729](lab7-详细设计文档.assets/image-20220709201729.png)

下图表明了在ERP系统中，Sale.manageState的相关对象之间的协作。

![image-20220709201824](lab7-详细设计文档.assets/image-20220709201824.png)

##### (5)业务逻辑层的实现原理

利用委托式控制风格，每个界面需要访问的业务逻辑由各自的控制器委托给不同的领域对象。

#### 4.1.4 SaleStrategybl模块

##### (1)模块概述

SaleStrategybl模块承担的需求参见需求规格说明文档功能需求及相关肺功能需求说明文档。

SaleStrategybl模块的职责及接口参见软件系统结构描述文档。

##### (2)整体结构

根据体系结构的设计，我们将系统分为了前端展示层、Controller层、业务逻辑层、数据层。每一层为了增加灵活性，我们会添加接口。例如，展示层和业务逻辑层之间，我们设置了Service接口。业务逻辑层和数据层之间设置了Mapper接口，且部分接口采用了Mybatis Plus技术。相关的Entity是作为与该模块相关的持久化对象而添加的设计模型中的。

**SaleStrategybl模块的设计如下图：**

![image-20220710004941.png](lab7-详细设计文档.assets/image-20220710004941.png)

**各个类的职责：**

| 模块                                                  | 职责                        |
|-----------------------------------------------------|---------------------------|
| SaleStrategyController                              | 负责促销策略相关功能的前后端交互          |
| GiftSheetController                                 | 负责赠品单相关功能的前后端交互           |
| SaleStrategyService                                 | 负责实现促销策略相关功能增查删等          |
| GiftSheetService                                    | 负责实现赠品单相关功能，如增查，审批等       |
| SaleStrategyDao                                     | 负责为促销策略相关功能提供数据层访问服务      |
| GroupConditionContentDao                            | 负责为促销、赠品单相关功能提供数据层访问服务    |
| GiftSheetDao                                        | 负责为赠品单相关功能提供数据层访问服务       |
| SaleStrategyPO\SaleStrategyVO\GroupConditionContent | 负责促销策略信息的保存，如促销策略类型等      |
| GiftSheetPO\GiftSheetVO\GiftSheetContentPO          | 负责赠品单相关功能实现的载体，存有赠品单编号等信息 |


##### (3)模块内部类的接口规范

SaleStrategybl模块的各个类的职责和内部类的接口规范已在ERP系统体系结构设计文档中描述。

##### **SaleStrategy模块的接口规范**

| 接口名称                                      | 语法                                 | 前置条件 | 后置条件                                              |
|-------------------------------------------|------------------------------------|------|---------------------------------------------------|
| SaleStrategyController.createSaleStrategy | createSaleStrategy(JSONObject obj) | 输入合法 | 将促销策略信息传递给后端SaleServiceImpls                      |
| SaleStrategyController.getAllSaleStrategy | getAllSaleStrategy()               | 无    | 从SaleService获得全部的促销信息                             |
| SaleStrategyController.getAllGroup        | getAllGroup(String saleStrategyId) | 输入合法 | 将saleStrategyId信息传递给SaleService                   |
| SaleStrategyController.deleteSaleStrategy | deleteStaff(String salStrategyId)  | 输入合法 | 将要被删除的策略的SaleStrategyId信息传递给后端SaleStrategyService |
| GiftSheetController.createGiftSheet | createGiftSheet(JSONObject obj)                   | 输入合法 | 将赠品单信息传递给GiftSheetService                   |
| GiftSheetController.getAllGiftSheet | getAllGiftSheet()                                 | 无    | 从GiftSheetService获取全部的赠品单信息                 |
| GiftSheetController.approval        | approval(String giftSheetId,GiftSheetState state) | 输入合法 | 将giftSheetId 和要改变的state信息传入GiftSheetService |
##### **SaleStrategy模块的服务接口**

| 服务名                                                                           | 服务                                                                    |
|-------------------------------------------------------------------------------|-----------------------------------------------------------------------|
| SimpleSaleStrategyImpl.createSaleStrategy(SaleStrategyVO saleStrategyVO)      | 将要添加的简单促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息    |
| GroupSaleStrategyImpl.createSaleStrategy(SaleStrategyVO saleStrategyVO)       | 将要添加的特价包促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息   |
| FillDeclineSaleStrategyImpl.createSaleStrategy(SaleStrategyVO saleStrategyVO) | 将要添加的满减、满送促销策略信息传递给SaleStrategyDao和GroupConditionContentDao,向表中插入相应信息 |
| SaleStrategyService.getAllSaleStrategy()                                      | 从SaleStrategyDao获取全部的促销策略信息                                           |
| SaleStrategyService.getAllGroup(String saleStrategyId)                        | 将需要查询赠品/特价包清单的促销策略id传递给GroupConditionContentDao                       |
| SaleStrategyService.deleteSaleStaff(String saleStrategyId)                    | 将要删除的促销策略信息传给SaleStrategyDao和GroupConditionContentDao。                |
| GiftSheetService.createGiftSheet( String saleSheetId,String saleStrategyId)   | 将要添加的赠品单信息传递给GiftSheetDao,SaleSheetId,GroupService，向表中插入相应信息          |
| GiftSheetService.getAllGiftSheet()                                            | 从GiftSheetDao获取全部赠品单信息                                                |
| GiftSheetService.approval(String giftSheetId,GiftSheetState state)            | 将赠品单信息和审批状态处理后传入GiftSheetDao,WarehouseDao中，更改相应状态                     |
| GroupService.getAllGroup(String saleStrategyId)                               | 将saleStrategyId传入GroupConditionContentDao中，获取相应的赠品/特价包清单              |

##### (4)业务逻辑层的动态模型

下图表明了在ERP系统中，SaleStrategy.createSaleStrategy的相关对象之间的协作。

![image-20220710030051.png](lab7-详细设计文档.assets/image-20220710030051.png)

下图表明了在ERP系统中，SaleStrategy.getAllSaleStrategy的相关对象之间的协作。

![image-20220710030206.png](lab7-详细设计文档.assets/image-20220710030206.png)

下图表明了在ERP系统中，SaleStrategy.deleteSaleStrategy的相关对象之间的协作。

![image-20220710030417.png](lab7-详细设计文档.assets/image-20220710030417.png)

下图表明了在ERP系统中，GiftSheet.createGiftSheet的相关对象之间的协作。

![image-20220710030616.png](lab7-详细设计文档.assets/image-20220710030616.png)

下图表明了在ERP系统中，GiftSheet.getAllGiftSheet的相关对象之间的协作。

![image-20220710030737](lab7-详细设计文档.assets/image-20220710030737.png)

下图表明了在ERP系统中，GiftSheet.approval的相关对象之间的协作。

![image-20220710030947](lab7-详细设计文档.assets/image-20220710030947.png)

##### (5)业务逻辑层的实现原理

利用委托式控制风格，每个界面需要访问的业务逻辑由各自的控制器委托给不同的领域对象。


## 5 依赖视角

下图分别是前端和后端各自的包之间的依赖关系。

![image-20220710101703754](lab7-详细设计文档.assets/image-20220710101703754.png)

![image-20220710101718003](lab7-详细设计文档.assets/image-20220710101718003.png)