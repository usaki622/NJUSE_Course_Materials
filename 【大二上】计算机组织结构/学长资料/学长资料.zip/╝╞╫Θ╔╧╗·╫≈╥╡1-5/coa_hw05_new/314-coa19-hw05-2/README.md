## COA2019

1.
在Cache类中实现fetch方法将数据从内存读到Cache(如果还没有加载到Cache)
并返回被更新的Cache行的行号(需要调用不同的映射策略和替换策略)

``` java
 String fetch(String sAddr, int len){
```

2.
实现三种映射策略(直接映射、全关联映射、组关联映射)和三种替换策略(先进先出、最少使用、最近使用)