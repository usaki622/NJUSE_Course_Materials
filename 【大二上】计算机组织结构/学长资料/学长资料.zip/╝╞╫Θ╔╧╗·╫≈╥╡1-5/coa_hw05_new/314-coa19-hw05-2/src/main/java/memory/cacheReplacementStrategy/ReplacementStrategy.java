package memory.cacheReplacementStrategy;

import memory.Cache;

import java.util.Calendar;

public abstract class ReplacementStrategy {
    Cache cacheInstance  = Cache.getCache();
    Cache.CacheLinePool cache = Cache.getCache().cache;
    Cache.CacheLine[] clPool = cache.clPool;
    /**
     * 在start-end范围内查找是否命中
     * @param start 起始行
     * @param end 结束行 闭区间
     */
    public int isHit(int start, int end, char[] addrTag){
        for(int i=start;i<=end;i++){
            if(clPool[i]==null)
                continue;
            if(String.valueOf(clPool[i].getTag()).equals(String.valueOf(addrTag))){
                if(!clPool[i].validBit)
                    continue;
                clPool[i].visited++;
                clPool[i].visitedTimeStamp = Calendar.getInstance().getTimeInMillis();
                return i;
            }
        }
        return -1;
    };

    public int write(int line, char[] addrTag, char[] input){
        clPool[line] = cacheInstance.new CacheLine();
        clPool[line].setTag(addrTag);
        clPool[line].setData(input);
        clPool[line].validBit = true;
        clPool[line].visited=1;
        clPool[line].inTimeStamp = Calendar.getInstance().getTimeInMillis();
        clPool[line].visitedTimeStamp = Calendar.getInstance().getTimeInMillis();
        return line;
    }

    /**
     * 在未命中的情况下将内存中的数写入cache
     * @param start 起始行
     * @param end 结束行 闭区间
     * @param addrTag tag
     * @param input  数据
     * @return
     */
    public abstract int writeCache(int start, int end, char[] addrTag, char[] input);
}
