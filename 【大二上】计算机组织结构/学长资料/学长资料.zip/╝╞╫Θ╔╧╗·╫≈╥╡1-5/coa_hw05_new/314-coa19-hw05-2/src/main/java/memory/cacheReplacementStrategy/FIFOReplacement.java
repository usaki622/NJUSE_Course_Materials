package memory.cacheReplacementStrategy;

import memory.Cache;

import java.util.Calendar;

/**
 * 先进先出算法
 */
public class FIFOReplacement extends ReplacementStrategy {

    @Override
    public int isHit(int start, int end, char[] addrTag) {
        return super.isHit(start,end,addrTag);
    }

    @Override
    public int writeCache(int start, int end, char[] addrTag, char[] input) {
        int line=start;
        long inTimeStamp = Calendar.getInstance().getTimeInMillis();
        for(int i=start;i<=end;i++){
            if(clPool[i]==null){
                line = i;
                break;}
            if(!clPool[i].validBit){
                line = i;
                break;
            }
            if(clPool[i].inTimeStamp<inTimeStamp){
                inTimeStamp = clPool[i].inTimeStamp;
                line = i;
            }
        }
        return super.write(line,addrTag,input);
    }


}
