package cpu.alu;

import transformer.Transformer;

public class NBCDU {

	// 模拟寄存器中的进位标志位
	private String CF = "0";

	// 模拟寄存器中的溢出标志位
	private String OF = "0";

	/**
	 *
	 * @param a A 32-bits NBCD String
	 * @param b A 32-bits NBCD String
	 * @return a + b
	 */
	String add(String a, String b) {
		String result = "";
		CF = "0";
		if(a.substring(0,4).equals(b.substring(0,4))){
			for(int i=7;i>=1;i--){
				int temp = new Transformer().valueOf(a.substring(4*i,4*i+4),2) +
						new Transformer().valueOf(b.substring(4*i,4*i+4),2) + Integer.parseInt(CF);
				if(temp>9){
					CF = "1";
					temp = temp + 6;
					result = new Transformer().getBCDString_4(temp-16) + result;
				}else {
					CF = "0";
					result = new Transformer().getBCDString_4(temp) + result;
				}
			}
			result = a.substring(0,4) + result;
		}else {
			if(b.substring(0,4).equals("1100")){
				return sub("1101"+b.substring(4),a);
			}else {
				return sub("1100" + b.substring(4),a);
			}
		}
		return result;
	}

	String inverse(String a){
		return new Transformer().getBCDString_4(9- new Transformer().valueOf(a,2));
	}
	/***
	 *
	 * @param a A 32-bits NBCD String
	 * @param b A 32-bits NBCD String
	 * @return b - a
	 */
	String sub(String a, String b) {
		String temp = "";
		for(int i=7;i>=1;i--){
			temp = inverse(a.substring(4*i,4*i+4)) + temp;
		}
		temp = a.substring(0,4) + temp;
		temp = add(temp,temp.substring(0,4) + new Transformer().getBCDString(1).substring(4));
		String result = add(b,temp);
		if(CF.equals("0")){
			temp = "";
			for(int i=7;i>=1;i--){
				temp = inverse(result.substring(4*i,4*i+4)) + temp;
			}
			if(result.substring(0,4).equals("1100")){
				temp = "1101" + temp;
			}else {
				temp = "1100" + temp;
			}
			result = temp;
			result = add(result,result.substring(0,4) + new Transformer().getBCDString(1).substring(4));

		}
		if(new Transformer().NBCDToDecimal(result).equals("0")){
			result = new Transformer().getBCDString(0);
		}
		return result;
	}

}
