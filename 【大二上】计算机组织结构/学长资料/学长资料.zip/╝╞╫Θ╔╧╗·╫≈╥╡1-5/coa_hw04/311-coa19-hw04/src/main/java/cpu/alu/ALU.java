package cpu.alu;

import transformer.Transformer;
import util.BinaryIntegers;
import util.IEEE754Float;

import java.util.Arrays;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 * TODO: 加减乘除
 */
public class ALU {

    // 模拟寄存器中的进位标志位
    private String CF = "0";

    // 模拟寄存器中的溢出标志位
    private String OF = "0";

    /**
     * 返回两个二进制整数的除法结果 operand1 ÷ operand2
     * @param operand1 32-bits
     * @param operand2 32-bits
     * @return 65-bits overflow + quotient + remainder
     */
    String div(String operand1, String operand2) {
        String temp = operand1.substring(0,operand2.length());
        String quotient;
        String sign = operand1.substring(0,1);
        if(operand1.equals(new Transformer().intToBinary("0"))){
            if(operand2.equals((new Transformer().intToBinary("0")))){
                return BinaryIntegers.NaN;
            }else {
                return "0" + BinaryIntegers.ZERO + BinaryIntegers.ZERO;
            }
        }
        // 判断除数是否为0
        if(operand2.equals(new Transformer().intToBinary("0"))){
            throw new ArithmeticException();
        }
        for(int i=0;i<operand2.length();i++){
            operand1 = sign + operand1;
        }
        if(isSameSign(operand2,temp)){
            operand1 = sub(operand2,operand1.substring(0,operand2.length())) + operand1.substring(operand2.length());
        }else {
            operand1 = add(operand2,operand1.substring(0,operand2.length())) + operand1.substring(operand2.length());
        }
        if(isSameSign(operand2,operand1)){
            quotient = "1";
        }else {
            quotient="0";
        }
        for(int i=0;i<operand2.length();i++){
            if(isSameSign(operand1,operand2)){
                operand1 = shl(new Transformer().intToBinary("1"),operand1);
                operand1 = operand1.substring(0,operand1.length()-1) + quotient;
                operand1 = sub(operand2,operand1.substring(0,operand2.length())) + operand1.substring(operand2.length());
            }
            else {
                operand1 = shl(new Transformer().intToBinary("1"),operand1);
                operand1 = operand1.substring(0,operand1.length()-1) + quotient;
                operand1 = add(operand1.substring(0,operand2.length()),operand2) + operand1.substring(operand2.length());
            }
            if(isSameSign(operand2,operand1))
                quotient="1";
            else
                quotient="0";
        }
        // 左移一位
        quotient = operand1.substring(operand2.length()+1) + quotient;

        if(quotient.substring(0,1).equals("1")){
            quotient = add(quotient,new Transformer().intToBinary("1"));
        }
        if(!isSameSign(operand1,temp)){
            if(isSameSign(temp,operand2)){
                operand1 = add(operand1.substring(0,operand2.length()),operand2) + operand1.substring(operand2.length());
            }else {
                operand1 = sub(operand2,operand1.substring(0,operand2.length())) + operand1.substring(operand2.length());
            }
        }
        if(operand1.substring(0,operand2.length()).equals(operand2)){
            quotient = add(quotient,new Transformer().intToBinary("1"));
            operand1 = BinaryIntegers.ZERO + operand1.substring(operand2.length());
        }
        temp = OF;
        if(add(operand1.substring(0,operand2.length()),operand2).equals(BinaryIntegers.ZERO)){
            quotient = sub(new Transformer().intToBinary("1"),quotient);
            operand1 = BinaryIntegers.ZERO + operand1.substring(operand2.length());
        }
        OF = temp;

        return OF + quotient + operand1.substring(0,operand2.length());
    }

    /**
     * 返回两个二进制整数的乘积(结果直接截取后32位)
     * 要求使用布斯乘法计算
     * @param src 32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    String mul (String src, String dest){
        String Y0 = "0";
        String Y1;
        for(int i=0;i<src.length();i++){
            dest = "0" + dest;
        }

        for(int i=0;i<src.length();i++){
            Y1 = dest.substring(dest.length()-1);
            int bias = Integer.parseInt(Y0) - Integer.parseInt(Y1);
            if(bias ==0){

            }else if(bias ==1){
                dest = add(dest.substring(0,dest.length()/2),src)+dest.substring(dest.length()/2);
            }else {
                dest = sub(src,dest.substring(0,dest.length()/2)) + dest.substring(dest.length()/2);
            }
            Y0 = Y1;
            dest = sar(new Transformer().intToBinary("1"),dest);
        }
        return dest.substring(dest.length()/2);
    }

    String mul_significands (String src, String dest){
        for(int i=0;i<3*src.length();i++){
            dest = "0" + dest;
        }
        for(int i=0;i<dest.length()/4;i++){
            src = "0" + src;
        }

        for(int i=0;i<23;i++){
            if(dest.substring(dest.length()-1).equals("1")){
                dest = add(src,dest.substring(0,dest.length()/2)) + dest.substring(dest.length()/2);
            }
            dest = shr(new Transformer().intToBinary("1"),dest);
        }
        dest = shl("1",dest);
        return dest;
    }


    //add two integer
    String add(String src, String dest) {
        String result = "";
        CF = "0";
        OF = "0";
        for(int i=dest.length()-1;i>=0;i--){
            String s = xor(xor(src.substring(i,i+1),dest.substring(i,i+1)),CF);
            result = s + result;
            CF = or(or(and(src.substring(i,i+1),dest.substring(i,i+1)),and(src.substring(i,i+1),CF)),and(dest.substring(i,i+1),CF));
        }
        OF = or(and(and(src.substring(0,1),dest.substring(0,1)),new Transformer().negation(result.substring(0,1))),
                and(and(new Transformer().negation(src.substring(0,1)),new Transformer().negation(dest.substring(0,1))),
                        result.substring(0,1)));
        return result;
    }

    //sub two integer
    // dest - src
    String sub(String src, String dest) {
        src = new Transformer().oneAdder(new Transformer().negation(src)).substring(1);
//        src = new Transformer().intToBinary(String.valueOf(-Integer.parseInt(new Transformer().binaryToInt(src))));
        return add(src,dest);
    }

    //signed integer mod
    String imod(String src, String dest) {
        String temp = dest.substring(0,32);
        String quotient;
        String sign = dest.substring(0,1);
        for(int i=0;i<32;i++){
            dest = sign + dest;
        }
        if(isSameSign(src,temp)){
            dest = sub(src,dest.substring(0,32)) + dest.substring(32);
        }else {
            dest = add(src,dest.substring(0,32)) + dest.substring(32);
        }
        if(isSameSign(src,dest)){
            quotient = "1";
        }else {
            quotient="0";
        }
        for(int i=0;i<32;i++){
            if(isSameSign(dest,src)){
                dest = shl(new Transformer().intToBinary("1"),dest);
                dest = dest.substring(0,dest.length()-1) + quotient;
                dest = sub(src,dest.substring(0,32)) + dest.substring(32);
            }
            else {
                dest = shl(new Transformer().intToBinary("1"),dest);
                dest = dest.substring(0,dest.length()-1) + quotient;
                dest = add(dest.substring(0,32),src) + dest.substring(32);
            }
            if(isSameSign(src,dest))
                quotient="1";
            else
                quotient="0";
        }
        quotient = dest.substring(32);
        quotient = shl(new Transformer().intToBinary("1"),quotient);
        if(quotient.substring(0,1).equals("1")){
            quotient = add(quotient,new Transformer().intToBinary("1"));
        }
        if(!isSameSign(dest,temp)){
            if(isSameSign(temp,src)){
                dest = add(dest.substring(0,32),src) + dest.substring(32);
            }else {
                dest = sub(src,dest.substring(0,32)) + dest.substring(32);
            }
        }
        return dest.substring(0,32);
    }

    boolean isSameSign(String src, String dest){
        if(src.substring(0,1).equals(dest.substring(0,1)))
            return true;
        else
            return false;
    }

    String and(String src, String dest) {
        String result="";
        for(int i=0;i<src.length();i++){
            if(src.substring(i,i+1).equals("1")&&dest.substring(i,i+1).equals("1"))
                result = result + "1";
            else
                result = result + "0";
        }
        return result;
    }

    String or(String src, String dest) {
        String result="";
        for(int i=0;i<src.length();i++){
            if(src.substring(i,i+1).equals("0")&&dest.substring(i,i+1).equals("0"))
                result = result + "0";
            else
                result = result + "1";
        }
        return result;
    }

    String xor(String src, String dest) {
        String result="";
        for(int i=0;i<src.length();i++){
            if(src.substring(i,i+1).equals(dest.substring(i,i+1)))
                result = result + "0";
            else
                result = result + "1";
        }
        return result;
    }

    String shl(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for(int i=0;i<num&&i<32;i++){
            dest = dest.substring(1) + "0";
        }
        return dest;
    }

    String shr(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for(int i=0;i<num&&i<dest.length();i++){
            dest = "0" + dest.substring(0,dest.length()-1);
        }
        return dest;
    }

    String sal(String src, String dest) {
        return shl(src,dest);
    }

    String sar(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for(int i=0;i<num&&i<dest.length();i++){
            dest = dest.substring(0,1) + dest.substring(0,dest.length()-1);
        }
        return dest;
    }

    String rol(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for (int i=0;i<num;i++){
            dest = dest.substring(1) + dest.substring(0,1);
        }
        return dest;
    }

    String ror(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for (int i=0;i<num;i++){
            dest = dest.substring(31) + dest.substring(0,31);
        }
        return dest;
    }

}
