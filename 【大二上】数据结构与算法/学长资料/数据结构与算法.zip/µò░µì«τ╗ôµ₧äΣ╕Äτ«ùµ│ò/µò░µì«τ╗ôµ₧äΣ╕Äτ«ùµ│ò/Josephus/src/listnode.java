public class listnode {
    public int data;
    public listnode next=null;

    public listnode(int data){
        this.data=data;
    }
}
