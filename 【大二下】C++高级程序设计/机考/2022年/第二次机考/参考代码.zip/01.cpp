#include <algorithm>
#include <cassert>
#include <iostream>
#include <memory>
#include <vector>

struct Position {
  size_t r;
  size_t c;
};

class Zombie;
class Plant;

using ZombieID = size_t;

class Board {
  friend class Game;

 public:
  static const size_t N_ROWS = 5;
  static const size_t N_COLS = 9;
  static const size_t N_COLS_EXTRA = N_COLS + 1;

  struct Cell {
    std::vector<ZombieID> zombies;
    std::shared_ptr<Plant> plant;
  };

 public:
  Board()
      : all_zombies_(),
        data_(N_ROWS, std::vector<Cell>(N_COLS_EXTRA)),
        n_plants_remained_(0),
        n_zombies_remained_(0),
        zombies_win_(false) {}
  ~Board() {}
  Board(const Board &) = delete;
  Board &operator=(const Board &) = delete;
  Board(Board &&) = delete;
  Board &operator=(Board &&) = delete;

  void place(Position pos, std::shared_ptr<Plant> a_plant);
  void place(Position pos, ZombieID zid);
  std::shared_ptr<Plant> plant_at(const size_t row, const size_t col) {
    return this->plant_at(Position{row, col});
  }
  std::shared_ptr<Plant> plant_at(Position pos);
  std::vector<ZombieID> &zombies_at(const size_t row, const size_t col) {
    return this->zombies_at(Position{row, col});
  }
  std::vector<ZombieID> &zombies_at(Position pos);
  Zombie &zombie_by_id(ZombieID zid);

  void zombie_dead();
  void plant_dead();

  void set_zombies_win();
  bool zombies_win() const { return zombies_win_; }

 private:
  std::vector<Zombie> all_zombies_;
  std::vector<std::vector<Cell>> data_;
  size_t n_plants_remained_;
  size_t n_zombies_remained_;
  bool zombies_win_;
};

class Piece {
 public:
  Piece() : atk_(0) {}
  Piece(size_t hp, size_t atk, std::shared_ptr<Board> board, Position pos)
      : hp_(hp), atk_(atk), board_(board), pos_(pos) {}

  virtual void attack() = 0;

 protected:
  Position pos_;
  std::shared_ptr<Board> board_;

  size_t hp_;
  size_t atk_;

  void decr_hp_by(size_t atk) {
    assert(hp_ > 0);

    // 注意无符号类型的溢出问题
    if (hp_ < atk) {
      hp_ = 0;
    } else {
      hp_ -= atk;
    }
  }
};

class Plant : public Piece {
 public:
  Plant(size_t hp, size_t atk, std::shared_ptr<Board> board, Position pos)
      : Piece(hp, atk, board, pos) {}

  // 只有土豆雷需要对此作出反应
  virtual void touched() {}
  // 土豆雷不会阻碍，其他植物只要存活就会阻碍
  virtual bool block() const { return hp_ > 0; }

  void attacked(size_t atk) {
    if (hp_ == 0) {
      return;
    }
    decr_hp_by(atk);
    if (hp_ == 0) {
      callback_on_hp_is_0();
    }
  }

 protected:
  void callback_on_hp_is_0() { board_->plant_dead(); }
};

class Pea : public Plant {
 public:
  Pea(size_t hp, size_t atk, std::shared_ptr<Board> board, Position pos)
      : Plant(hp, atk, board, pos) {}

  void attack() override;
};

class Nut : public Plant {
 public:
  Nut(size_t hp, std::shared_ptr<Board> board, Position pos)
      : Plant(hp, 0, board, pos) {}

  // 坚果墙不会攻击
  void attack() override {}
};

class Potato : public Plant {
 public:
  Potato(size_t atk, std::shared_ptr<Board> board, Position pos)
      : Plant(0, atk, board, pos), state_(State::INACTIVATED) {}

  void attack() override;
  void touched() override {
    if (state_ == State::INACTIVATED) {
      state_ = State::ACTIVATED;
    }
  }

  bool block() const override { return false; }

  static const size_t RANGE = 1;

 private:
  enum class State { INACTIVATED, ACTIVATED, USED };
  State state_;
};

class Zombie : public Piece {
 public:
  Zombie(size_t id, size_t hp, size_t atk, size_t speed,
         std::shared_ptr<Board> board, Position pos)
      : Piece(hp, atk, board, pos), id_(id), speed_(speed) {}
  Zombie(const Zombie &that)
      : Piece(that.hp_, that.atk_, that.board_, that.pos_),
        id_(that.id_),
        speed_(that.speed_) {}

  void attack() override;
  void attacked(size_t atk) {
    if (hp_ == 0) {
      return;
    }
    decr_hp_by(atk);
    if (hp_ == 0) {
      callback_on_hp_is_0();
    }
  }

  void march();

 private:
  size_t id_;
  size_t speed_;

  void step_left();

  void callback_on_hp_is_0() {
    board_->zombie_dead();
    auto &cell = board_->zombies_at(pos_);
    cell.erase(std::remove_if(cell.begin(), cell.end(), [this](ZombieID zid) {
      return zid == this->id_;
    }));
  }
};

class Game {
 public:
  Game() : board_(std::make_shared<Board>()), round_no_(1) {}

  void set_up();
  void go();

 private:
  std::shared_ptr<Board> board_;
  size_t round_no_;

  void print_stats() const;
};

void Board::set_zombies_win() { zombies_win_ = true; }

void Board::place(Position pos, std::shared_ptr<Plant> a_plant) {
  auto &cell = data_[pos.r][pos.c];
  assert(!cell.plant);
  cell.plant = a_plant;
  n_plants_remained_++;
}

void Board::place(Position pos, ZombieID zid) {
  auto &cell = data_[pos.r][pos.c];
  cell.zombies.push_back(zid);
  n_zombies_remained_++;
}

void Zombie::attack() {
  if (hp_ == 0) {
    return;
  }
  auto p = board_->plant_at(pos_);
  if (!p) {
    return;
  }
  p->attacked(atk_);
}

void Zombie::step_left() {
  assert(hp_ > 0);

  auto &old_cell = board_->zombies_at(pos_);
  old_cell.erase(
      std::remove_if(old_cell.begin(), old_cell.end(),
                     [this](ZombieID zid) { return zid == this->id_; }));
  // 已经在 col = 0 的位置，这样向左一步就走出了花园，即，可以吃到脑子
  if (pos_.c == 0) {
    board_->set_zombies_win();
    return;
  }
  pos_ = Position{pos_.r, pos_.c - 1};
  auto &new_cell = board_->zombies_at(pos_);
  new_cell.push_back(this->id_);
}

void Zombie::march() {
  if (hp_ == 0) {
    return;
  }

  for (size_t i = 0; i < speed_; i++) {
    // 如果当前所处格子有障碍，是不能移动的
    auto a_plant = board_->plant_at(pos_);
    if (a_plant != nullptr && a_plant->block()) {
      break;
    }
    step_left();
    if (board_->zombies_win()) {
      break;
    }
    a_plant = board_->plant_at(pos_);
    if (a_plant) {
      a_plant->touched();
    }
  }
}

void Pea::attack() {
  if (hp_ == 0) {
    return;
  }
  std::vector<ZombieID> zombies;
  for (size_t c = pos_.c; c < Board::N_COLS_EXTRA; c++) {
    // 注意此处不能使用引用，因为 zombies 中的元素可能会被删除，导致迭代器失效
    zombies = board_->zombies_at(Position{pos_.r, c});
    if (!zombies.empty()) {
      break;
    }
  }
  if (zombies.empty()) {
    return;
  }
  for (auto zid : zombies) {
    auto &z = board_->zombie_by_id(zid);
    z.attacked(atk_);
  }
}

void Potato::attack() {
  if (state_ != State::ACTIVATED) {
    return;
  }
  size_t begin_row = pos_.r >= RANGE ? pos_.r - RANGE : 0,
         end_row = std::min(pos_.r + RANGE, size_t{5}),
         begin_col = pos_.c >= RANGE ? pos_.c - RANGE : 0,
         end_col = std::min(pos_.c + RANGE, size_t{9});
  for (size_t r = begin_row; r <= end_row; r++) {
    for (size_t c = begin_col; c <= end_col; c++) {
      auto &zombies = board_->zombies_at(r, c);
      for (auto zid : zombies) {
        auto &z = board_->zombie_by_id(zid);
        z.attacked(atk_);
      }
    }
  }

  hp_ = 0;
  state_ = State::USED;
  callback_on_hp_is_0();
}

std::shared_ptr<Plant> Board::plant_at(Position pos) {
  return data_[pos.r][pos.c].plant;
}

std::vector<ZombieID> &Board::zombies_at(Position pos) {
  return data_[pos.r][pos.c].zombies;
}

Zombie &Board::zombie_by_id(ZombieID zid) { return all_zombies_[zid]; }

void Board::zombie_dead() { n_zombies_remained_--; }

void Board::plant_dead() { n_plants_remained_--; }

void Game::set_up() {
  size_t n_plants, n_zombies;
  std::cin >> n_plants >> n_zombies;

  std::string plant_name;
  size_t hp, atk, row, col;
  for (size_t i = 0; i < n_plants; i++) {
    std::cin >> plant_name;
    std::shared_ptr<Plant> p;
    if (plant_name == "pea") {
      std::cin >> hp >> atk >> row >> col;
      p = std::make_shared<Pea>(hp, atk, board_, Position{row, col});
    } else if (plant_name == "nut") {
      std::cin >> hp >> row >> col;
      p = std::make_shared<Nut>(hp, board_, Position{row, col});
    } else if (plant_name == "potato") {
      std::cin >> atk >> row >> col;
      p = std::make_shared<Potato>(atk, board_, Position{row, col});
    } else {
      assert(false);
    }
    board_->place(Position{row, col}, p);
  }

  size_t speed;
  for (size_t i = 0; i < n_zombies; i++) {
    std::cin >> hp >> atk >> speed >> row;
    Position pos = Position{row, Board::N_COLS};
    Zombie z(i, hp, atk, speed, board_, pos);
    board_->all_zombies_.push_back(z);
    board_->place(pos, i);
  }
}

void Game::go() {
  while (true) {
    // Stage 1. 植物进行攻击
    for (size_t r = 0; r < Board::N_ROWS; r++) {
      for (size_t c = 0; c < Board::N_COLS; c++) {
        auto p = board_->plant_at(Position{r, c});
        if (!p) {
          continue;
        }
        p->attack();
      }
    }

    // Stage 2. 僵尸移动
    for (size_t r = 0; r < Board::N_ROWS; r++) {
      for (size_t c = 0; c < Board::N_COLS_EXTRA; c++) {
        // 特别注意这里不能使用引用，因为会从单元格中删除僵尸，导致迭代器失效
        auto zombies = board_->zombies_at(Position{r, c});
        for (auto zid : zombies) {
          auto &z = board_->zombie_by_id(zid);
          z.march();
        }
      }
    }

    // Stage 3. 僵尸攻击
    for (size_t r = 0; r < Board::N_ROWS; r++) {
      for (size_t c = 0; c < Board::N_COLS; c++) {
        auto &zombies = board_->zombies_at(Position{r, c});
        for (auto zid : zombies) {
          auto &z = board_->zombie_by_id(zid);
          z.attack();
        }
      }
    }

    // Stage 4. 输出统计信息
    print_stats();

    // Stage 5. 判断游戏是否结束
    // 不存在同归于尽，即僵尸数和植物数同时为 0 的情况
    if (board_->n_zombies_remained_ == 0) {
      // 植物胜利
      std::cout << "plants win" << std::endl;
      break;
    } else if (board_->zombies_win()) {
      // 僵尸胜利
      std::cout << "zombies win" << std::endl;
      break;
    }

    round_no_++;
  }
}

void Game::print_stats() const {
#ifdef MYDEBUG
  std::cout << "Round #" << round_no_
            << ", #plants: " << board_->n_plants_remained_
            << ", #zombies: " << board_->n_zombies_remained_ << std::endl;
#else
  std::cout << round_no_ << ' ' << board_->n_plants_remained_ << ' '
            << board_->n_zombies_remained_ << std::endl;
#endif
}

int main() {
  Game my_game;
  my_game.set_up();
  my_game.go();
}