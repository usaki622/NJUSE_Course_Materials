// 此文件模拟2022年c++第二次机考题 植物大战僵尸

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Plant;

class Zombie {
 public:
  Zombie(int hp, int att, int speed, int x);
  // 尝试移动speed的长度
  void move(vector<Plant*> plants);
  bool moveOne(vector<Plant*> plants);
  void attack(vector<Plant*> plants);
  void minus(int hp);
  bool isAlive();
  int getX();
  int getY();
  int getSpeed();

 private:
  int x;
  int y = 9;
  int hp;
  int att;
  int speed = 0;
};

class Plant {
 public:
  // 攻击模版
  void attack(vector<Zombie*> zombies) {
    if (isAlive() && attackable) {
      doAttack(zombies);
    }
  }
  virtual void doAttack(vector<Zombie*> zombies) = 0;
  Plant(int hp, int att, bool able, int x, int y, bool stop)
      : hp(hp), att(att), attackable(able), stoppable(stop), x(x), y(y) {}
  int getX() { return this->x; }
  int getY() { return this->y; }
  void setX(int x) { this->x = x; }
  void setAttackable(bool flag) { this->attackable = flag; }
  bool getAttackable() { return this->attackable; }
  bool isAlive() { return this->hp > 0; }
  bool getStoppable() { return this->stoppable; }
  void minus(int hp) { this->hp -= hp; }

 protected:
  int x;
  int y;
  int hp;
  int att;
  // 植物是否可以攻击
  bool attackable;
  // 植物是否能阻挡
  bool stoppable;
};

// 豌豆
class Pea : public Plant {
 public:
  Pea(int hp, int att, int x, int y) : Plant(hp, att, true, x, y, true) {}
  void doAttack(vector<Zombie*> zombies) {
    //先找到当前植物右边的第一个僵尸
    int minY = 10;
    for (int i = 0; i < zombies.size(); i++) {
      // 僵尸挂了 或者 僵尸不在和植物一行上
      if (!zombies[i]->isAlive() || zombies[i]->getX() != this->getX()) {
        continue;
      }
      if (zombies[i]->getY() >= this->getY()) {
        if (zombies[i]->getY() < minY) {
          minY = zombies[i]->getY();
        }
      }
    }
    // 右边没找到僵尸
    if (minY == 10) {
      return;
    }

    // 攻击
    for (int i = 0; i < zombies.size(); i++) {
      if (!zombies[i]->isAlive() || zombies[i]->getX() != x) {
        continue;
      }
      if (zombies[i]->getY() == minY) {
        zombies[i]->minus(att);
      }
    }
  }
};

// 土豆雷
class Potato : public Plant {
 public:
  Potato(int att, int x, int y) : Plant(100, att, false, x, y, false) {}
  void doAttack(vector<Zombie*> zombies) {
    // 计算爆炸的区域
    int beginX = x - 1;
    int endX = x + 1;
    int beginY = y - 1;
    // 爆炸最大的范围不能超过右边界9
    int endY = y + 1 > 9 ? 9 : y + 1;
    for (int i = 0; i < zombies.size(); i++) {
      int zombieX = zombies[i]->getX();
      int zombieY = zombies[i]->getY();
      if (zombies[i]->isAlive() && zombieX >= beginX && zombieX <= endX &&
          zombieY >= beginY && zombieY <= endY) {
        zombies[i]->minus(att);
      }
    }
    this->hp = 0;
  }
};

// 坚果
class Nut : public Plant {
 public:
  // 这里把坚果设置未不能攻击
  Nut(int hp, int x, int y) : Plant(hp, 0, false, x, y, true) {}
  void doAttack(vector<Zombie*> zombies) {}
};

Zombie::Zombie(int hp, int att, int speed, int x)
    : hp(hp), att(att), speed(speed), x(x) {}
// 尝试移动speed的长度
void Zombie::move(vector<Plant*> plants) {
  if (!isAlive()) {
    return;
  }
  for (int i = 0; i < speed; i++) {
    bool flag = moveOne(plants);
    if (!flag) {
      return;
    }
  }
};
// 尝试往左移动一步
bool Zombie::moveOne(vector<Plant*> plants) {
  // if(y == 0){
  //     y = -1;
  //     return false;
  // }
  for (int i = 0; i < plants.size(); i++) {
    // 植物存活并占同一个格子并阻挡
    if (plants[i]->isAlive() && plants[i]->getY() == y &&
        plants[i]->getX() == x && plants[i]->getStoppable()) {
      return false;
    }
  }
  // 左移一步
  y--;
  if (y < 0) {
    return false;
  }
  // 主要是激活土豆雷
  for (int i = 0; i < plants.size(); i++) {
    if (plants[i]->isAlive() && plants[i]->getX() == x &&
        plants[i]->getY() == y)
      plants[i]->setAttackable(true);
  }
  return true;
}
void Zombie::attack(vector<Plant*> plants) {
  if (!isAlive()) {
    return;
  }
  for (int i = 0; i < plants.size(); i++) {
    if (plants[i]->isAlive() && plants[i]->getX() == x &&
        plants[i]->getY() == y && plants[i]->getStoppable()) {
      plants[i]->minus(att);
    }
  }
};
void Zombie::minus(int hp) { this->hp -= hp; }
bool Zombie::isAlive() { return this->hp > 0; }
int Zombie::getX() { return this->x; }
int Zombie::getY() { return this->y; }
int Zombie::getSpeed() { return this->speed; }

vector<Plant*> plants;
vector<Zombie*> zombies;

bool isEnd() {
  for (int i = 0; i < zombies.size(); i++) {
    if (zombies[i]->isAlive() && zombies[i]->getY() < 0) {
      cout << "zombies win" << endl;
      return true;
    }
  }

  for (int i = 0; i < zombies.size(); i++) {
    // 有僵尸存活，并且在花园中，游戏继续
    if (zombies[i]->isAlive()) {
      return false;
    }
  }

  // 没有僵尸存活
  cout << "plants win" << endl;
  return true;
}

int main() {
  int num_p, num_z;
  cin >> num_p >> num_z;
  for (int i = 0; i < num_p; i++) {
    string p;
    Plant* plant = nullptr;
    cin >> p;
    if (p == "pea") {
      int hp, att, x, y;
      cin >> hp >> att >> x >> y;
      plant = new Pea(hp, att, x, y);
    } else if (p == "potato") {
      int att, x, y;
      cin >> att >> x >> y;
      plant = new Potato(att, x, y);
    } else if (p == "nut") {
      int hp, x, y;
      cin >> hp >> x >> y;
      plant = new Nut(hp, x, y);
    }
    plants.push_back(plant);
  }

  for (int i = 0; i < num_z; i++) {
    int hp, att, speed, x;
    cin >> hp >> att >> speed >> x;
    Zombie* z = new Zombie(hp, att, speed, x);
    zombies.push_back(z);
  }

  int round = 1;
  while (true) {
    for (int i = 0; i < plants.size(); i++) {
      plants[i]->attack(zombies);
    }

    for (int i = 0; i < zombies.size(); i++) {
      zombies[i]->move(plants);
    }

    for (int i = 0; i < zombies.size(); i++) {
      zombies[i]->attack(plants);
    }

    int plantCount = 0;
    int zombieCount = 0;
    for (int i = 0; i < plants.size(); i++) {
      if (plants[i]->isAlive()) {
        plantCount++;
      }
    }

    for (int i = 0; i < zombies.size(); i++) {
      if (zombies[i]->isAlive()) {
        zombieCount++;
      }
    }
    cout << round << " " << plantCount << " " << zombieCount << endl;
    round++;
    if (isEnd()) {
      break;
    }
  }
}