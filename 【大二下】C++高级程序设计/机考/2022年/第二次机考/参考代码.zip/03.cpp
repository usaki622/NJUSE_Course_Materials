#include <cassert>
#include <iostream>
#include <map>
#include <vector>

using namespace std;
// int lb, int rb, int lu, int ru
using Range = tuple<int, int, int, int>;

//#define DEBUG

struct GameElement {
  int Hp{-1};
  int ATK{-1};
  int RANGE{-1};
  int row;
  int col;

  GameElement(int hp, int atk, int range, int row, int col)
      : Hp(hp), ATK(atk), RANGE(range), row(row), col(col) {}

  virtual void print() {
    cout << "Hp: " << Hp << "\trow: " << row << "\tcol: " << col << endl;
  }

  bool isAlive() const { return Hp > 0; }

  virtual int getATK() { return ATK; }

  int getHp() const { return Hp; }

  void beAttacked(int atk) {
    if (Hp - atk <= 0) {
      Hp = 0;
    } else {
      Hp -= atk;
    }
  }

  bool inRange(const Range &R) const {
    return row >= get<0>(R) && row <= get<1>(R) && col >= get<2>(R) &&
           col <= get<3>(R);
  }

  virtual Range getAttackRange() const {
    return {row - RANGE, row + RANGE, col - RANGE, col + RANGE};
  }

  Range getLocation() const { return {row, row, col, col}; }
};

struct Plant : public GameElement {
  Plant() = delete;

  Plant(int hp, int atk, int range, int row, int col)
      : GameElement(hp, atk, range, row, col) {}

  virtual bool canStopZombie() const = 0;

  virtual bool isAOE() const { return false; }
};

struct PlantPea : public Plant {
  PlantPea(int hp, int atk, int row, int col) : Plant(hp, atk, 10, row, col) {}

  bool canStopZombie() const override { return true; }

  Range getAttackRange() const override {
    int right_most = col + RANGE;
    if (right_most > 9) {
      right_most = 9;
    }
    return {row, row, col, right_most};
  }

  bool isAOE() const override { return false; }

  virtual void print() {
    cout << "pea:\tHp: " << Hp << "\trow: " << row << "\tcol: " << col << endl;
  }
};

struct PlantPotato : public Plant {
  PlantPotato(int atk, int row, int col) : Plant(99999, atk, 3, row, col) {}

  bool canStopZombie() const override { return false; }

  Range getAttackRange() const override {
    int temp = RANGE / 2;
    int row_up = (row - temp) < 0 ? 0 : row - temp;
    int row_down = (row + temp) > 5 ? 5 : row + temp;
    int col_left = (col - temp) < 0 ? 0 : col - temp;
    int col_right = (col + temp) > 9 ? 9 : col + temp;
    return {row_up, row_down, col_left, col_right};
  }

  bool isAOE() const override { return true; }

  void trigger() { this->Hp = 0; }

  virtual void print() {
    std::string CurHp = Hp > 0 ? "infinite" : "0";
    cout << "potato:\tHp: " << CurHp << "\trow: " << row << "\tcol: " << col
         << endl;
  }
};

struct PlantNut : public Plant {
  PlantNut(int hp, int row, int col) : Plant(hp, 0, 0, row, col) {}

  bool canStopZombie() const override { return true; }

  Range getAttackRange() const override { return {-1, -1, -1, -1}; }

  bool isAOE() const override { return true; }

  virtual void print() {
    cout << "nut:\tHp: " << Hp << "\trow: " << row << "\tcol: " << col << endl;
  }
};

struct Zombie : public GameElement {
  int SPEED{-1};

  Zombie() = delete;

  Zombie(int hp, int atk, int speed, int row)
      : SPEED(speed), GameElement(hp, atk, 0, row, 9) {}

  Range getAttackRange() const override { return {row, row, col, col}; }

  Range getMoveRange() const { return {row, row, col - SPEED, col}; }

  bool canWalkPast(int min_col, int max_col, Plant *p) {
    int cur_col = get<2>(p->getLocation());
    return cur_col >= min_col && cur_col <= max_col;
  }

  vector<PlantPotato *> move(vector<Plant *> &plants) {
    return move(col - SPEED, plants);
  }

  vector<PlantPotato *> move(int dest_col, vector<Plant *> &plants) {
    vector<PlantPotato *> can_triggered;
    for (auto p : plants) {
      if (auto potato = dynamic_cast<PlantPotato *>(p)) {
        if (canWalkPast(dest_col, col, potato)) {
          can_triggered.push_back(potato);
        }
      }
    }
    col = dest_col;
    return can_triggered;
  }

  virtual void print() {
    cout << "zombie:\tHp: " << Hp << "\trow: " << row << "\tcol: " << col
         << endl;
  }
};

class Game {
 private:
  vector<Plant *> plants;
  vector<Zombie *> zombies;

  vector<PlantPotato *> triggered_potato;

  bool brain_dead{false};

  bool all_zombies_dead() const {
    bool all_dead = true;
    for (auto zombie : zombies) {
      if (zombie->getHp() > 0) {
        all_dead = false;
      }
    }
    return all_dead;
  }

  vector<Zombie *> findLeftMostZombies(vector<Zombie *> &zombies) const {
    vector<Zombie *> res;
    int min_col = 10;
    for (auto z : zombies) {
      if (z->col < min_col) {
        min_col = z->col;
      }
    }
    for (auto z : zombies) {
      if (z->col == min_col) {
        res.push_back(z);
      }
    }
    return res;
  }

  Plant *findRightMostPlant(vector<Plant *> &plants) const {
    int max_col = 0;
    for (auto p : plants) {
      if (!p->isAlive()) continue;
      if (!p->canStopZombie()) continue;
      if (p->col > max_col) {
        max_col = p->col;
      }
    }
    for (auto p : plants) {
      if (!p->isAlive()) continue;
      if (!p->canStopZombie()) continue;
      if (p->col == max_col) {
        return p;
      }
    }
    return nullptr;
  }

  void init() {
    int n_p, n_z;
    cin >> n_p >> n_z;
    for (int i = 0; i < n_p; i++) {
      string type;
      cin >> type;
      Plant *p = nullptr;
      if (type == "pea") {
        int hp, atk, row, col;
        cin >> hp >> atk >> row >> col;
        p = new PlantPea(hp, atk, row, col);
      } else if (type == "potato") {
        int atk, row, col;
        cin >> atk >> row >> col;
        p = new PlantPotato(atk, row, col);
      } else if (type == "nut") {
        int hp, row, col;
        cin >> hp >> row >> col;
        p = new PlantNut(hp, row, col);
      }
      assert(p != nullptr);
      plants.push_back(p);
    }
    for (int i = 0; i < n_z; i++) {
      int hp, atk, speed, row;
      cin >> hp >> atk >> speed >> row;
      zombies.push_back(new Zombie(hp, atk, speed, row));
    }
  }

  void plant_attack() {
    for (auto TP : triggered_potato) {
      TP->trigger();
      for (Zombie *z : zombies) {
        if (z->inRange(TP->getAttackRange())) {
          z->beAttacked(TP->getATK());
        }
      }
    }
    triggered_potato.clear();

    for (Plant *plant : this->plants) {
      if (!plant->isAlive()) continue;

      if (auto Potato = dynamic_cast<PlantPotato *>(plant)) {
        continue;
      } else {
        vector<Zombie *> zs;
        for (Zombie *z : zombies) {
          if (!z->isAlive()) continue;
          if (z->inRange(plant->getAttackRange())) {
            zs.push_back(z);
          }
        }
        zs = findLeftMostZombies(zs);
        for (Zombie *z : zs) {
          z->beAttacked(plant->getATK());
        }
      }
    }
  }

  void zombie_move() {
    std::map<int, vector<Plant *>> plantsByRow;
    for (Plant *plant : plants) {
      if (plant->isAlive()) {
        plantsByRow[plant->row].push_back(plant);
      }
    }
    std::map<int, Plant *> leftMostPlantByRow;
    for (int i = 0; i < 5; ++i) {
      if (plantsByRow[i].empty()) {
        leftMostPlantByRow[i] = nullptr;
      }
      leftMostPlantByRow[i] = findRightMostPlant(plantsByRow[i]);
    }

    for (Zombie *z : zombies) {
      if (!z->isAlive()) {
        continue;
      }
      Plant *lm = leftMostPlantByRow[z->row];
      if (lm != nullptr) {
        if (lm->inRange(z->getMoveRange())) {
          triggered_potato = z->move(lm->col, plants);
          continue;
        }
      }
      triggered_potato = z->move(plants);
    }
  }

  void zombie_attack() {
    for (Zombie *z : zombies) {
      if (!z->isAlive()) continue;
      if (z->col < 0) {
        this->brain_dead = true;
        continue;
      }
      for (Plant *p : plants) {
        if (p->inRange(z->getAttackRange())) {
          p->beAttacked(z->getATK());
        }
      }
    }
  }

 public:
  void debug_print(bool is_init = false) {
#ifdef DEBUG
    if (is_init) {
      std::cout << "init status:" << std::endl;
    }
    std::cout << "====================================" << std::endl;
    for (int i = 0; i < plants.size(); i++) {
      if (plants[i]->isAlive()) {
        plants[i]->print();
      }
    }
    std::cout << "alive zombies:" << std::endl;
    for (int i = 0; i < zombies.size(); i++) {
      if (zombies[i]->isAlive()) {
        zombies[i]->print();
      }
    }
    std::cout << "====================================\n\n" << std::endl;
#endif
  }

  void run() {
    init();
    debug_print(true);
    int round = 1;
    while (true) {
      plant_attack();
      zombie_move();
      zombie_attack();

      int remain_p = 0;
      int remain_z = 0;
      for (Plant *p : plants) {
        if (p->isAlive()) {
          remain_p++;
        }
      }
      for (Zombie *z : zombies) {
        if (z->isAlive()) {
          remain_z++;
        }
      }
      std::cout << round << " " << remain_p << " " << remain_z << std::endl;
      round++;

      debug_print();

      if (brain_dead) {
        std::cout << "zombies win" << std::endl;
        break;
      }
      if (all_zombies_dead()) {
        std::cout << "plants win" << std::endl;
        break;
      }
    }
  }
};

int main() {
  Game game;
  game.run();
  return 0;
}