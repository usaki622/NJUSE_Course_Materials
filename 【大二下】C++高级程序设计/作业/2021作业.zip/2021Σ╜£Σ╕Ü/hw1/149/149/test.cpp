#include <iostream>
#include <fstream>
#include <string>

using namespace std;

char indexMap(int num) {
	if (0 <= num && num < 26) {
		return 'A' + num;
	}
	else if (26 <= num && num < 52)
	{
		return 'a' + (num - 26);
	}
	else if (52 <= num && num < 62) {
		return '0' + (num - 52);
	}
	else if (num == 62) {
		return '+';
	}
	else if (num == 63) {
		return '/';
	}
	else {
		return '=';
	}
}

int main() {
	char c1, c2, c3;
	int i;
	int code = 0;
	string textName;
	cin >> textName;
	string file_path = "C:\\Users\\wyh0111jx\\Desktop\\CPP\\hw1\\Q149\\" + textName;
	//cout << "file: " << file_path << endl;
	ifstream fin(file_path, ios_base::binary);
	if (!fin.is_open()) {
		cout << "FILE NOT FOUND";
	}

	bool flg1 = false;
	bool flg2 = false;

	while (fin.get(c1)) {
		code += ((c1 & 0xff) << 16);
		if (fin.get(c2)) {
			code += ((c2 & 0xff) << 8);
			if (fin.get(c3)) {
				code += (c3 & 0xff);
			}
			else {
				flg1 = true;
			}
		}
		else {
			flg2 = true;
		}
		int move = 18;
		int tmp = 0xfc0000;
		int time = 0;
		while (move >= 0) {
			if (time == 2 && flg2) {
				cout << "==" << endl;
				break;
			}
			if (time == 3 && flg1) {
				cout << "=" << endl;
				break;
			}
			i = (code & tmp) >> move;
			cout << indexMap(i);
			tmp >>= 6;
			move -= 6;
			time++;
		}
		code = 0;
	}	
	if (!flg1 && !flg2) {
		cout << endl;
	}
}